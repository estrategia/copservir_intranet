<h2>Resumen de reseñas del contenido</h2>
<span>5 Estrellas</span>
<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: <?= $datos['5'] * 100 / $datos['total'] . '%;' ?> ">
  </div>
</div>

<span>4 Estrellas</span>
<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: <?= $datos['4'] * 100 / $datos['total'] . '%;' ?> ">
  </div>
</div>

<span>3 Estrellas</span>
<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: <?= $datos['3'] * 100 / $datos['total'] . '%;' ?> ">
  </div>
</div>

<span>2 Estrellas</span>
<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: <?= $datos['2'] * 100 / $datos['total'] . '%;' ?> %">
  </div>
</div>

<span>1 Estrellas</span>
<div class="progress">
  <div class="progress-bar" role="progressbar" style="width: <?= $datos['1'] * 100 / $datos['total'] . '%;' ?> %">
  </div>
</div>