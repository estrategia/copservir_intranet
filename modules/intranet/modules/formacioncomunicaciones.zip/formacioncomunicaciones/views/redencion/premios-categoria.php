<?php 
  
?>
<h2>
  <?= $categoria->nombreCategoria ?>
</h2>