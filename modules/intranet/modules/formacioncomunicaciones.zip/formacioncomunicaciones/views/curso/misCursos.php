<?php 
use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use yii\widgets\ListView;
use kartik\rating\StarRating;

$this->title = 'Programas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div>
  <h2>
    Programas
  </h2>
    <!-- <a href="<?= Url::to('recomendados') ?>" class="btn btn-default">Recomendados <span class="glyphicon glyphicon-star"></span></a> -->
    <!-- <a href="<?= Url::to('leidos') ?>" class="btn btn-default">Terminados <span class="glyphicon glyphicon-ok-circle"></span></a> -->
</div>
<br>
<?= ListView::widget([
    'dataProvider' => $dataProvider,
    'itemView' => '_item_misCursos',
    'pager' => [
        'prevPageLabel' => 'Anterior',
        'nextPageLabel' => 'Siguiente',
        'maxButtonCount' => 3,
    ],
]); ?>