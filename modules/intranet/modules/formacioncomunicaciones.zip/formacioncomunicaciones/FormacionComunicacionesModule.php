<?php

namespace app\modules\intranet\modules\formacioncomunicaciones;

/**
 * formacioncomunicaciones module definition class
 */
class FormacionComunicacionesModule extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'app\modules\intranet\modules\formacioncomunicaciones\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
