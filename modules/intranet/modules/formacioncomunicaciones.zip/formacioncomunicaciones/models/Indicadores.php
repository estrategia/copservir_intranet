<?php 

namespace app\modules\intranet\modules\formacioncomunicaciones\models;

use Yii;

class Indicadores
{
    public static function cursosNuevos()
    {
        // Cursos nuevos del mes
        // $fechaPasada = date('Y-m-d', strtotime('-1 week'));
        $fechaPasada = date('Y-m-01 00:00:00');
        
        if (false) {
            $fechaPasada = date('Y-m-d', strtotime('-1 month'));
        }
        // var_dump($fechaPasada);
        $cursosNuevos = (new yii\db\Query())
            ->from('m_FORCO_Contenido')
            ->where(['>=', 'fechaCreacion', $fechaPasada])
            ->count();
        return $cursosNuevos;
    }

    public function cursosNuevosDisponibles()
    {
        // Cursos nuevos 
        // $fechaPasada = $next_week = date('Y-m-d 00:00:00', strtotime('-1 week'));
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        // $fechaPasada = date('Y-m-01 00:00:00');
        $cursosNuevos = (new yii\db\Query())
            ->from('m_FORCO_Contenido')
            ->leftJoin('t_FORCO_ContenidoLeidoUsuario', 'm_FORCO_Contenido.idContenido = t_FORCO_ContenidoLeidoUsuario.idContenido')
            ->where(['t_FORCO_ContenidoLeidoUsuario.idContenido' => null])
            // ->where(['>=', 'fechaCreacion', $fechaPasada])
            ->andWhere(['estadoContenido' => Contenido::ESTADO_ACTIVO])
            ->andWhere(['numeroDocumento' => $numeroDocumento])
            ->count();
        return $cursosNuevos;
    }

    public static function cursosHechos()
    {
        // Cursos terminados
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        $cursosHechos = (new yii\db\Query())
            ->from('t_FORCO_ContenidoLeidoUsuario')
            ->where("numeroDocumento = {$numeroDocumento}")
            ->count();
        return $cursosHechos;
    }

    public static function cursosPendientes()
    {
        // Cursos pendientes activos asignados por el grupo de interes
        $gruposInteres = (array) Yii::$app->user->identity->getGruposCodigos();
        $gruposInteres[] = 999999;
        
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        $subQueryModulos = Modulo::find()
            ->select('idModulo')
            ->joinWith('curso')
            ->where(['estadoModulo' => Modulo::ESTADO_ACTIVO])
            ->andWhere(['estadoCurso' => Curso::ESTADO_ACTIVO]);


        $capitulosObligatorios = Capitulo::find()
            ->select('m_FORCO_Capitulo.idCapitulo')
            ->joinWith('objGruposInteres')
            ->where([
                'estadoCapitulo' => Capitulo::ESTADO_ACTIVO,
                'idModulo' => $subQueryModulos,
                'm_GrupoInteres.idGrupoInteres' => $gruposInteres,
            ]);

        $contenidosLeidos = ContenidoLeidoUsuario::find()
            ->joinWith('contenido')
            ->where(['numeroDocumento' => $numeroDocumento])
            ->andWhere(['estadoContenido' => Contenido::ESTADO_ACTIVO])
            ->all();
        
        $idsTerminados = \yii\helpers\ArrayHelper::getColumn($contenidosLeidos, 'idContenido');

        $contenidosPendientes = Contenido::find()
            ->select('idContenido')
            ->where(['idCapitulo' => $capitulosObligatorios])
            ->andWhere(['NOT IN', 'idContenido', $idsTerminados])
            ->andWhere(['estadoContenido' => Contenido::ESTADO_ACTIVO])
            ->count();

        return $contenidosPendientes;
    }

    public static function puntosObtenidos()
    {
        // Puntos del mes
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        $inicioMes = date('Y-m-01 00:00:00');
        $puntosObtenidos = (new yii\db\Query())
            ->select(['SUM(valorPuntos)'])
            ->from('t_FORCO_Puntos')
            ->where(['numeroDocumento' => $numeroDocumento])
            ->andWhere(['>=', 'fechaCreacion', $inicioMes])
            ->scalar();
        return $puntosObtenidos;
    }

    public static function puntosTotales()
    {
        // Puntos totales historicos
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        $puntosObtenidos = (new yii\db\Query())
            ->select(['SUM(valorPuntos)'])
            ->from('t_FORCO_Puntos')
            ->where(['numeroDocumento' => $numeroDocumento])
            ->scalar();
        return $puntosObtenidos;
    }

    // public static function ranking()
    // {
    //     $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
    //     $sql = "
    //     SELECT rank FROM
    //         (SELECT numeroDocumento, @curRank := @curRank + 1 AS rank
    //             FROM t_FORCO_PromedioPonderadoUsuario p, (SELECT @curRank := 0) r
    //             ORDER BY promedio DESC
    //         ) AS ranking
    //     WHERE numeroDocumento = {$numeroDocumento}";

    //     $db = Yii::$app->db;
    //     $command = $db->createCommand($sql);
    //     $rank = $command->queryScalar();
    //     return $rank;
    // }

    public function ranking()
    {
        $numeroDocumento = Yii::$app->user->identity->numeroDocumento;
        $inicioMes = date('Y-m-01 00:00:00');
        $sql = "
        SELECT rank 
        FROM (
        SELECT numeroDocumento, puntos, @curRank := @curRank + 1 AS rank 
            FROM (
                SELECT numeroDocumento, SUM(valorPuntos) AS puntos 
                FROM t_FORCO_Puntos
                WHERE fechaCreacion >= '{$inicioMes}'
                GROUP BY numeroDocumento
                ORDER BY puntos DESC
            ) AS acumulado, (SELECT @curRank := 0) r
        ) AS rank
        WHERE numeroDocumento = {$numeroDocumento}";
        $db = Yii::$app->db;
        $command = $db->createCommand($sql);
        $rank = $command->queryScalar();
        return $rank;
    }

    public function top()
    {
        $inicioMes = date('Y-m-01 00:00:00');
        $sql = "
        SELECT numeroDocumento, puntos, @curRank := @curRank + 1 AS rank 
        FROM (
            SELECT numeroDocumento, SUM(valorPuntos) AS puntos 
            FROM t_FORCO_Puntos
            WHERE fechaCreacion >= '{$inicioMes}'
            GROUP BY numeroDocumento
            ORDER BY puntos DESC
            LIMIT 10
        ) AS acumulado, (SELECT @curRank := 0) r";
            // WHERE fechaCreacion >= '{$inicioMes}'

        $db = Yii::$app->db;
        $command = $db->createCommand($sql);
        $top = $command->queryAll();
        return $top;
    }
}