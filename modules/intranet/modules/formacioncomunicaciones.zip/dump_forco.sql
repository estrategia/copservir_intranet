-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: 192.168.1.30    Database: intranet2
-- ------------------------------------------------------
-- Server version	5.5.47-0+deb7u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `m_FORCO_Capitulo`
--

DROP TABLE IF EXISTS `m_FORCO_Capitulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Capitulo` (
  `idCapitulo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombreCapitulo` varchar(45) NOT NULL,
  `descripcionCapitulo` varchar(250) NOT NULL,
  `estadoCapitulo` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idModulo` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idCapitulo`),
  KEY `fk_m_FORCO_Capitulo_m_FORCO_Modulo` (`idModulo`),
  CONSTRAINT `fk_m_FORCO_Capitulo_m_FORCO_Modulo` FOREIGN KEY (`idModulo`) REFERENCES `m_FORCO_Modulo` (`idModulo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Capitulo`
--

LOCK TABLES `m_FORCO_Capitulo` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Capitulo` DISABLE KEYS */;
INSERT INTO `m_FORCO_Capitulo` VALUES (2,'Capitulo 1','Horario de trabajo',1,'2017-03-27 14:29:11','2017-03-29 23:19:50',2),(3,'captitulo 1.1','badgbadasdfsa',1,'2017-03-29 11:32:25','2017-03-29 16:35:21',4),(4,'capitulo 1.2','safsafdaf',1,'2017-03-29 11:33:06','2017-03-29 16:32:34',4),(5,'Enteros','Enteros',1,'2017-04-06 10:11:47','2017-04-06 15:11:14',5),(6,'Cap1','asdf',1,'2017-04-19 15:34:45','2017-04-19 20:34:12',6),(7,'Cap1','asdfasdf',1,'2017-04-19 15:34:53','2017-04-19 20:34:20',7),(8,'Cap2','asdfha',1,'2017-04-19 15:35:01','2017-04-19 20:34:28',6),(9,'Introducción','Introducción al modelo de servicio',1,'2017-05-05 10:48:02','2017-05-05 15:47:30',8),(10,'Componentes del modelo de servicio','Componentes del modelo de servicio',1,'2017-05-08 15:39:43','2017-05-08 20:39:11',8),(11,'Recopilación','Resumen de pasos del modelo de servicio',1,'2017-05-08 15:53:23','2017-05-08 20:52:51',8),(12,'Cap1','Cap1',1,'2017-05-31 10:44:02','2017-05-31 15:43:35',3),(13,'Capitulo 1','Capitulo 1',1,'2017-06-14 09:13:32','2017-06-14 14:13:08',9),(14,'Capítulo 1','Capítulo 1',1,'2017-06-14 09:25:26','2017-06-14 14:25:01',10),(15,'Introducción','Capitulo I',1,'2017-07-07 11:45:55','2017-07-07 16:45:29',12),(16,'Un tutorial sencillo','Tutorial sencillo',1,'2017-07-07 12:02:44','2017-07-07 17:02:18',12);
/*!40000 ALTER TABLE `m_FORCO_Capitulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_CategoriasPremios`
--

DROP TABLE IF EXISTS `m_FORCO_CategoriasPremios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_CategoriasPremios` (
  `idCategoria` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombreCategoria` varchar(100) DEFAULT NULL,
  `orden` int(5) unsigned NOT NULL,
  `rutaIcono` varchar(256) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `idCategoriaPadre` int(11) unsigned DEFAULT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idCategoria`),
  KEY `fk_m_FORCO_CategoriasPremios_m_FORCO_CategoriasPremios` (`idCategoriaPadre`),
  CONSTRAINT `fk_m_FORCO_CategoriasPremios_m_FORCO_CategoriasPremios` FOREIGN KEY (`idCategoriaPadre`) REFERENCES `m_FORCO_CategoriasPremios` (`idCategoria`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_CategoriasPremios`
--

LOCK TABLES `m_FORCO_CategoriasPremios` WRITE;
/*!40000 ALTER TABLE `m_FORCO_CategoriasPremios` DISABLE KEYS */;
INSERT INTO `m_FORCO_CategoriasPremios` VALUES (7,'Regalo de proveedores',1,'1495059508_.png',1,NULL,'2017-04-24 09:17:29','2017-05-17 22:17:58'),(8,'Articulos deportivos',2,'1493417955_.png',1,NULL,'2017-04-24 09:17:52','2017-04-28 22:18:43'),(9,'Prueba hijo',1,'1493043496_.jpg',1,7,'2017-04-24 09:18:16','2017-04-24 14:17:43'),(11,'Prueba hijo2',1,'1493043621_.png',1,8,'2017-04-24 09:20:21','2017-04-24 14:19:49'),(12,'Beneficios',2,'1493418027_.png',1,NULL,'2017-04-24 09:55:22','2017-04-28 22:19:54'),(13,'Viajes',4,'1493418078_.png',1,NULL,'2017-04-24 09:55:50','2017-04-28 22:20:45'),(14,'Prueba 5',5,'',1,NULL,'2017-04-24 10:22:02','2017-06-14 16:28:23'),(15,'Electrodomésticos',0,'1493417723_.jpg',1,NULL,'2017-04-24 10:24:58','2017-04-28 22:14:50'),(16,'Prueba sub',1,'1493420780_.jpg',1,14,'2017-04-28 18:06:20','2017-04-28 23:05:48'),(17,'Horno',2,'1493824680_.jpg',1,14,'2017-05-03 10:18:00','2017-05-03 15:17:27'),(18,'Batidora',3,'1493825942_.jpg',1,14,'2017-05-03 10:38:18','2017-05-03 15:38:29');
/*!40000 ALTER TABLE `m_FORCO_CategoriasPremios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_ContactoCategoria`
--

DROP TABLE IF EXISTS `m_FORCO_ContactoCategoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_ContactoCategoria` (
  `idCategoriaPremio` int(10) unsigned NOT NULL,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`idCategoriaPremio`,`numeroDocumento`),
  KEY `fk_m_FORCO_ContactoCategoria_m_INTRA_Usuario` (`numeroDocumento`),
  CONSTRAINT `fk_m_FORCO_ContactoCategoria_m_FORCO_CategoriasPremios` FOREIGN KEY (`idCategoriaPremio`) REFERENCES `m_FORCO_CategoriasPremios` (`idCategoria`),
  CONSTRAINT `fk_m_FORCO_ContactoCategoria_m_INTRA_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_INTRA_Usuario` (`numeroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_ContactoCategoria`
--

LOCK TABLES `m_FORCO_ContactoCategoria` WRITE;
/*!40000 ALTER TABLE `m_FORCO_ContactoCategoria` DISABLE KEYS */;
INSERT INTO `m_FORCO_ContactoCategoria` VALUES (8,94504074),(8,1113618983);
/*!40000 ALTER TABLE `m_FORCO_ContactoCategoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Contenido`
--

DROP TABLE IF EXISTS `m_FORCO_Contenido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Contenido` (
  `idContenido` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contenido` longtext,
  `estadoContenido` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `idCapitulo` int(10) unsigned NOT NULL,
  `idContenidoCopia` int(10) unsigned DEFAULT NULL,
  `frecuenciaMes` tinyint(3) unsigned DEFAULT '0',
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tituloContenido` varchar(255) NOT NULL,
  `descripcionContenido` varchar(255) NOT NULL,
  `idCurso` int(10) unsigned DEFAULT NULL,
  `tiempoRequerido` int(10) unsigned NOT NULL,
  `cantidadPuntos` int(10) unsigned NOT NULL,
  `idTercero` int(11) NOT NULL,
  `nombreProveedor` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`idContenido`),
  KEY `fk_m_FORCO_Contenido_m_FORCO_Capitulo1_idx` (`idCapitulo`),
  KEY `fk_m_FORCO_Contenido_m_FORCO_Contenido1_idx` (`idContenidoCopia`),
  KEY `fk_m_FORCO_Contenido_m_FORCO_Curso` (`idCurso`),
  CONSTRAINT `fk_m_FORCO_Contenido_m_FORCO_Capitulo1` FOREIGN KEY (`idCapitulo`) REFERENCES `m_FORCO_Capitulo` (`idCapitulo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_m_FORCO_Contenido_m_FORCO_Contenido1` FOREIGN KEY (`idContenidoCopia`) REFERENCES `m_FORCO_Contenido` (`idContenido`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_m_FORCO_Contenido_m_FORCO_Curso` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Contenido`
--

LOCK TABLES `m_FORCO_Contenido` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Contenido` DISABLE KEYS */;
INSERT INTO `m_FORCO_Contenido` VALUES (2,'<p><img src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/imagenes/cover_pic_58da903918c0c.png\"></p>',1,2,NULL,NULL,'2017-03-27 14:29:35','2017-06-14 13:35:28','Prueba','Horario de llegada',4,0,0,0,NULL),(5,'<p><iframe class=\"iframe-contenido-curso\" src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/paquetes/5/index.html\"></iframe></p>',1,2,NULL,NULL,'2017-04-05 17:33:57','2017-06-14 13:36:07','Presentación','Desembolsemos el planeta',4,0,0,0,NULL),(6,'<p><iframe width=\"500\" height=\"281\" src=\"//www.youtube.com/embed/NEq4YsGooys\" frameborder=\"0\" allowfullscreen=\"\"></iframe></p>',1,5,NULL,2,'2017-04-06 10:12:15','2017-04-06 15:12:30','Enteros sin signo','Enteros sin signo',8,0,0,0,NULL),(7,NULL,1,6,NULL,0,'2017-04-19 15:35:14','2017-04-19 20:34:42','asdf','asdf',9,20,0,0,NULL),(8,NULL,1,8,NULL,0,'2017-04-19 15:35:31','2017-04-19 20:34:58','asdf','asdf',9,50,0,0,NULL),(9,NULL,1,7,NULL,0,'2017-04-19 15:35:42','2017-04-19 20:35:09','dashfghd','afsdf',9,20,0,0,NULL),(10,'<p><video class=\"video-editor\" controls=\"\"><source src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/archivos/marca-omnicanal_5910d5bfab098.mp4\" type=\"video/mp4\"></video> <br></p>',1,9,NULL,NULL,'2017-05-05 10:51:41','2017-07-07 16:45:07','Marca omnicanal','Somos una marca Onmicanal. Es decir, integramos todos nuestros canales de venta, generando múltiples opciones para que un cliente que inicia una compra por un canal pueda continuarla fácilmente por otro',11,5,0,-1,'COPSERVIR'),(11,'<p><video class=\"video-editor\" controls=\"\"><source src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/archivos/modelo-de-servicio-introduccion_5910d706c0b1c.mp4\" type=\"video/mp4\"></video> <br>\r\n</p>',1,9,NULL,NULL,'2017-05-05 10:58:18','2017-07-07 16:45:16','Modelo de servicio','Introducción al modelo de servicio de copservir',11,5,0,-1,'COPSERVIR'),(12,'<p><video class=\"video-editor\" controls=\"\"><source src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/archivos/modelo-de-servicio-componentes_5910d892e663d.mp4\" type=\"video/mp4\"></video> <br></p>',1,10,NULL,NULL,'2017-05-08 15:42:28','2017-07-07 16:48:00','Introducción, pasos 1 y 2','Introducción, pasos 1 y 2 del modelo de servicio',11,20,0,5,'LABORATORIOS ZAHYE S A'),(13,NULL,1,10,NULL,0,'2017-05-08 15:44:40','2017-05-08 20:44:08','Paso 3','Paso 3 del modelo de servicio',11,20,0,0,NULL),(14,'',1,10,NULL,NULL,'2017-05-08 15:45:09','2017-07-07 16:48:18','Paso 4','Paso 4 del modelo de servicio',11,20,0,53,'LABORATORIOS CHALVER DE COLOMBIA S A'),(15,'',1,10,NULL,NULL,'2017-05-08 15:45:52','2017-07-07 16:48:35','Paso 5','Paso 5 del modelo de servicio',11,20,0,87,'COBO & ASOCIADOS DE OCCIDENTE S.A'),(16,'',1,10,NULL,NULL,'2017-05-08 15:46:16','2017-07-07 16:48:51','Paso 6','Paso 6 del modelo de servicio',11,20,0,601,'DISTRIBUIDORA PROVEMOS DEL SUR LTDA'),(17,NULL,1,11,NULL,0,'2017-05-08 15:54:03','2017-05-08 20:53:31','Resumen','Resumen de pasos del modelo',11,20,0,0,NULL),(18,'<iframe class=\"iframe-contenido-curso\" src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/paquetes/18/index.html\"></iframe>',1,12,NULL,NULL,'2017-05-31 10:44:20','2017-06-14 13:36:34','Capsula','Desembolsemos el planeta',4,20,0,0,NULL),(19,NULL,1,13,NULL,0,'2017-06-14 09:15:23','2017-06-14 14:14:59','Contenido principal','Contenido Principal',12,10,0,0,NULL),(20,'<iframe class=\"iframe-contenido-curso\" src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/paquetes/20/index.html\"></iframe>',1,14,NULL,NULL,'2017-06-14 09:27:17','2017-06-14 14:46:30','Contenido','Contneido',12,60,0,0,NULL),(21,'<video class=\"video-editor\" controls=\"\"><source src=\"/copservir_intranet/web/formacioncomunicaciones/contenidos/archivos/marca-omnicanal_5941550a3ae86.mp4\" type=\"video/mp4\"></video> <br>',1,13,NULL,NULL,'2017-06-14 10:16:30','2017-06-14 15:23:57','Contenido 2','Contenido 2',12,22,0,0,NULL),(22,NULL,1,11,NULL,0,'2017-07-07 10:06:02','2017-07-07 15:05:38','Prueba','Proveedor',11,10,0,-1,'COPSERVIR'),(23,'<p><acronym>PHP</acronym> (acrónimo recursivo de <em>PHP: Hypertext Preprocessor</em>) es un lenguaje de código abierto muy popular especialmente adecuado para el desarrollo web y que puede ser incrustado en HTML.</p><p>Bien, pero ¿qué significa realmente? Un ejemplo nos aclarará las cosas:</p><div><div><p><strong>Ejemplo #1 Un ejemplo introductorio</strong></p></div><div><div><code>&lt;!DOCTYPE HTML&gt;<br>&lt;html&gt;<br>    &lt;head&gt;<br>        &lt;title&gt;Ejemplo&lt;/title&gt;<br>    &lt;/head&gt;<br>    &lt;body&gt;<br><br>        &lt;?php<br>            echo \"¡Hola, soy un script de PHP!\";<br>        ?&gt;<br><br>    &lt;/body&gt;<br>&lt;/html&gt;</code></div></div></div><p>En lugar de usar muchos comandos para mostrar HTML (como en C o en Perl), las páginas de PHP contienen HTML con código incrustado que hace \"algo\" (en este caso, mostrar \"¡Hola, soy un script de PHP!). El código de PHP está encerrado entre las <a href=\"http://php.net/manual/es/language.basic-syntax.phpmode.php\" class=\"link\">etiquetas especiales de comienzo y final <code>&lt;?php</code> y <code>?&gt;</code></a> que permiten entrar y salir del \"modo PHP\".</p><p>Lo que distingue a PHP de algo del lado del cliente como Javascript es que el código es ejecutado en el servidor, generando HTML y enviándolo al cliente. El cliente recibirá el resultado de ejecutar el script, aunque no se sabrá el código subyacente que era. El servidor web puede ser configurado incluso para que procese todos los ficheros HTML con PHP, por lo que no hay manera de que los usuarios puedan saber qué se tiene debajo de la manga.</p><p>Lo mejor de utilizar PHP es su extrema simplicidad para el principiante, pero a su vez ofrece muchas características avanzadas para los programadores profesionales. No sienta miedo de leer la larga lista de características de PHP. En unas pocas horas podrá empezar a escribir sus primeros scripts.</p><p>Aunque el desarrollo de PHP está centrado en la programación de scripts del lado del servidor, se puede utilizar para muchas otras cosas. Siga leyendo y descubra más en la sección <a href=\"http://php.net/manual/es/intro-whatcando.php\" class=\"link\">¿Qué puede hacer PHP?</a>, o vaya directo al <a href=\"http://php.net/manual/es/tutorial.php\" class=\"link\">tutorial introductorio</a>si solamente está interesado en programación web.</p>',1,15,NULL,NULL,'2017-07-07 11:50:03','2017-07-07 16:50:56','Que es php','Que es php',14,10,0,-1,'COPSERVIR'),(24,'<p>ualquier cosa. PHP está enfocado principalmente a la programación de scripts del lado del servidor, por lo que se puede hacer cualquier cosa que pueda hacer otro programa CGI, como recopilar datos de formularios, generar páginas con contenidos dinámicos, o enviar y recibir cookies. Aunque PHP puede hacer mucho más.</p><p>Existen principalmente tres campos principales donde se usan scripts de PHP.</p><ul><li><span class=\"simpara\">Scripts del lado del servidor. Este es el campo más tradicional y el foco principal. Son necesarias tres cosas para que esto funcione. El analizador de PHP (módulo CGI o servidor), un servidor web y un navegador web. Es necesario ejecutar el servidor con una instalación de PHP conectada. Se puede acceder al resultado del programa de PHP con un navegador, viendo la página de PHP a través del servidor. Todo esto se puede ejecutar en su máquina si está experimentado con la programación de PHP. Véase la sección sobre las<a href=\"http://php.net/manual/es/install.php\" class=\"link\">instrucciones de instalación</a> para más información.</span></li><li><span class=\"simpara\">Scripts desde la línea de comandos. Se puede crear un script de PHP y ejecutarlo sin necesidad de un servidor o navegador. Solamente es necesario el analizador de PHP para utilizarlo de esta manera. Este tipo de uso es ideal para scripts que se ejecuten con regularidad empleando cron (en *nix o Linux) o el Planificador de tareas (en Windows). Estos scripts también pueden usarse para tareas simples de procesamiento de texto. Véase la sección <a href=\"http://php.net/manual/es/features.commandline.php\" class=\"link\">Uso de PHP en la línea de comandos</a> para más información.</span></li><li><span class=\"simpara\">Escribir aplicaciones de escritorio. Probablemente PHP no sea el lenguaje más apropiado para crear aplicaciones de escritorio con una interfaz gráfica de usuario, pero si se conoce bien PHP, y se quisiera utilizar algunas características avanzadas de PHP en aplicaciones del lado del cliente, se puede utilizar PHP-GTK para escribir dichos programas. También es posible de esta manera escribir aplicaciones independientes de una plataforma. PHP-GTK es una extensión de PHP, no disponible en la distribución principal. Si está interesado en PHP-GTK, puede visitar su propio <a href=\"http://gtk.php.net/\" class=\"link external\">»  sitio web</a>.</span></li></ul><p>PHP puede <a href=\"http://php.net/manual/es/install.php\" class=\"link\">emplearse</a> en todos los sistemas operativos principales, incluyendo Linux, muchas variantes de Unix (incluyendo HP-UX, Solaris y OpenBSD), Microsoft Windows, Mac OS X, RISC OS y probablemente otros más. PHP admite la mayoría de servidores web de hoy en día, incluyendo Apache, IIS, y muchos otros. Esto incluye cualquier servidor web que pueda utilizar el binario de PHP FastCGI, como lighttpd y nginx. PHP funciona tanto como módulo como procesador de CGI.</p><p>De modo que con PHP, se tiene la libertad de elegir el sistema operativo y el servidor web. Además, se tiene la posibilidad de utilizar programación por procedimientos o programación orientada a objetos (POO), o una mezcla de ambas.</p><p>Con PHP no se está limitado a generar HTML. Entre las capacidades de PHP se incluyen la creación de imágenes, ficheros PDF e incluso películas Flash (usando libswf y Ming) generadas sobre la marcha. También se puede generar fácilmente cualquier tipo de texto, como XHTML y cualquier otro tipo de fichero XML. PHP puede autogenerar estos ficheros y guardarlos en el sistema de ficheros en vez de imprimirlos en pantalla, creando una caché en el lado del servidor para contenido dinámico.</p><p>Una de las características más potentes y destacables de PHP es su soporte para un <a href=\"http://php.net/manual/es/refs.database.php\" class=\"link\">amplio abanico de bases de datos</a>. Escribir una página web con acceso a una base de datos es increíblemente simple utilizando una de las extensiones específicas de bases de datos (p.ej., para <a href=\"http://php.net/manual/es/book.mysqli.php\" class=\"link\">mysql</a>), o utilizar una capa de abstracción como <a href=\"http://php.net/manual/es/book.pdo.php\" class=\"link\">PDO</a>, o conectarse a cualquier base de datos que admita el estándar de Conexión Abierta a Bases de Datos por medio de la extensión <a href=\"http://php.net/manual/es/book.uodbc.php\" class=\"link\">ODBC</a>. Otras bases de datos podrían utilizar <a href=\"http://php.net/manual/es/book.curl.php\" class=\"link\">cURL</a> o <a href=\"http://php.net/manual/es/book.sockets.php\" class=\"link\">sockets</a>, como lo hace CouchDB.</p><p>PHP también cuenta con soporte para comunicarse con otros servicios usando protocolos tales como LDAP, IMAP, SNMP, NNTP, POP3, HTTP, COM (en Windows) y muchos otros. También se pueden crear sockets de red puros e interactuar usando cualquier otro protocolo. PHP tiene soporte para el intercambio de datos complejos de WDDX entre virtualmente todos los lenguajes de programación web. Y hablando de interconexión, PHP tiene soporte para la instalación de objetos de Java y emplearlos de forma transparente como objetos de PHP.</p><p>PHP tiene útiles características de <a href=\"http://php.net/manual/es/refs.basic.text.php\" class=\"link\">procesamiento de texto</a>, las cuales incluyen las expresiones regulares compatibles con Perl (<a href=\"http://php.net/manual/es/book.pcre.php\" class=\"link\">PCRE</a>), y muchas extensiones y herramientas para el <a href=\"http://php.net/manual/es/refs.xml.php\" class=\"link\">acceso y análisis de documentos XML</a>. PHP estandariza todas las extensiones XML sobre el fundamento sólido de <a href=\"http://php.net/manual/es/book.libxml.php\" class=\"link\">libxml2</a>, y amplía este conjunto de características añadiendo soporte para <a href=\"http://php.net/manual/es/book.simplexml.php\" class=\"link\">SimpleXML</a>, <a href=\"http://php.net/manual/es/book.xmlreader.php\" class=\"link\">XMLReader</a> y <a href=\"http://php.net/manual/es/book.xmlwriter.php\" class=\"link\">XMLWriter</a>.</p><p>Existen otras extensiones interesantes, las cuales están categorizadas<a href=\"http://php.net/manual/es/extensions.php\" class=\"link\">alfabéticamente</a> y por <a href=\"http://php.net/manual/es/funcref.php\" class=\"link\">categoría</a>. También hay extensiones adicionales de PECL que podrían estar documentadas o no dentro del manual de PHP, tal como <a href=\"http://xdebug.org/\" class=\"link external\">» XDebug</a>.</p><p>Como se puede apreciar, esta página no es suficiente para enumerar todas las características y beneficios que ofrece PHP. Consulte las secciones <a href=\"http://php.net/manual/es/install.php\" class=\"link\">Instalación de PHP</a> y <a href=\"http://php.net/manual/es/funcref.php\" class=\"link\">Referencia de las funciones</a> para una explicación de las extensiones mencionadas aquí.</p>',1,15,NULL,NULL,'2017-07-07 12:00:39','2017-07-07 17:01:28','Que se puede hacer con php','Que se puede hacer',14,4,0,-1,'COPSERVIR'),(25,'<div><p>En este manual se asume que se cuenta con un servidor que tiene soporte activado para PHP y que todos los ficheros con la extensión <var>.php</var> son tratados por PHP. En la mayoría de servidores, esta es la extensión predeterminada para los ficheros de PHP, aunque puede preguntar al administrador de su servidor para estar seguro. Si el servidor tiene soporte para PHP, entonces no es necesario hacer nada. Simplemente cree sus ficheros <var>.php</var>, guárdelos en su directorio web y el servidor los analizará por usted. No hay necesidad de compilar nada o instalar otras herramientas. Piense en estos ficheros habilitados para PHP como simples ficheros HTML con el añadido de una nueva familia de etiquetas mágicas que permiten todo tipo de cosas.</p><p>Digamos que quiere ahorrar el preciado ancho de banda y trabajar localmente. En este caso, querrá instalar un servidor web, como <a href=\"http://httpd.apache.org/\" class=\"link external\">» Apache</a>, y por supuesto <a href=\"http://www.php.net/downloads.php\" class=\"link external\">» PHP</a>. Lo más seguro es que también quiera instalar una base de datos como <a href=\"http://dev.mysql.com/doc/\" class=\"link external\">» MySQL</a>.</p><p>Puede instalarlos de forma independiente o bien puede elegir una manera más sencilla. Este manual contiene <a href=\"http://php.net/manual/es/install.php\" class=\"link\">Instrucciones de instalación de PHP</a> (asumiendo que tiene algún tipo de servidor web ya configurado). Si tuviera problemas con la instalación, sugerimos que formule sus preguntas en nuestra <a href=\"http://www.php.net/mailing-lists.php\" class=\"link external\">» lista de correo de instalación</a>. Si elige la manera más sencilla, <a href=\"http://wikipedia.org/wiki/List_of_AMP_packages\" class=\"link external\">» localice un paquete preconfigurado</a>para su sistema operativo, el cual instala automáticamente todo esto con únicamente unos pocos clics de ratón. Es sencillo configurar un servidor web con soporte para PHP en cualquier sistema operativo, incluyendo MacOSX, Linux y Windows. En Linux, podría encontrar útil <a href=\"http://www.rpmfind.net/\" class=\"link external\">» rpmfind</a> y <a href=\"http://rpm.pbone.net/\" class=\"link external\">» PBone</a> para localizar los RPM. También puede visitar <a href=\"https://packages.debian.org/index\" class=\"link external\">» apt-get</a> para buscar paquetes para Debian..</p></div><section><div><span class=\"action\"><br></span></div></section>',1,16,NULL,NULL,'2017-07-07 12:03:36','2017-07-07 17:06:36','Que necesito?','Necesito',14,3,0,-1,'COPSERVIR'),(26,'<p>Comience por crear un fichero llamado <var>hola.php</var> y póngalo en el directorio raíz de su servidor web (<var><var>DOCUMENT_ROOT</var></var>) con el siguiente contenido:</p><div><div><p><strong>Ejemplo #1 Nuestro primer script de PHP: <var>hola.php</var></strong></p></div><div><div><code>&lt;html&gt;<br> &lt;head&gt;<br>  &lt;title&gt;Prueba de PHP&lt;/title&gt;<br> &lt;/head&gt;<br> &lt;body&gt;<br> &lt;?php echo \'&lt;p&gt;Hola Mundo&lt;/p&gt;\'; ?&gt;<br> &lt;/body&gt;<br>&lt;/html&gt;</code></div></div><div><p>Utilice su navegador web para acceder al fichero con el URL de su servidor, finalizado con la referencia al fichero <em>/hola.php</em>. Si está programando localmente, este URL será algo parecido a <em><a href=\"http://localhost/hola.php\">http://localhost/hola.php</a></em> o<em><a href=\"http://127.0.0.1/hola.php\">http://127.0.0.1/hola.php</a></em>, pero esto depende de la configuración de su servidor web. Si todo está configurado correctamente, el fichero será analizado por PHP y se enviará el siguiente contenido a su navegador:</p></div><div><div><pre>&lt;html&gt;\r\n &lt;head&gt;\r\n  &lt;title&gt;Prueba de PHP&lt;/title&gt;\r\n &lt;/head&gt;\r\n &lt;body&gt;\r\n &lt;p&gt;Hola mundo&lt;/p&gt;\r\n &lt;/body&gt;\r\n&lt;/html&gt;\r\n</pre></div></div></div><p>Este programa es extremadamente simple y realmente no es necesario utilizar PHP para crear una página como esta. Lo único que muestra es: <em>Hola mundo</em>empleando la sentencia <span class=\"function\"><a href=\"http://php.net/manual/es/function.echo.php\" class=\"function\">echo</a></span> de PHP. Observe que el fichero <em>no necesita ser ejecutable</em> o especial de ninguna forma. El servidor reconoce que este fichero necesita ser interpretado por PHP debido al empleo de la extensión \".php\", ya que el servidor está configurado para enviarlo a PHP. Piense como si fuera un fichero HTML normal que tiene una serie de etiquetas especiales disponibles con las que puede hacer muchas cosas interesantes.</p><p>Si intentó usar este ejemplo y no produjo ningún resultado, se le preguntó si deseaba descargar el fichero, o se mostró todo el fichero como texto, lo más seguro es que PHP no se encuentre habilitado en su servidor o no esté configurado adecuadamente. Pídale a su administrador que lo habilite utilizando el capítulo <a href=\"http://php.net/manual/es/install.php\" class=\"link\">Instalación</a> del manual. Si está trabajando localmente, lea también el capítulo dedicado a la instalación para asegurarse de que todo esté configurado adecuadamente. Asegúrese de que está accediendo al fichero mediante http y que el servidor muestre el resultado. Si está abriendo el fichero desde el sistema de ficheros, probablemente no será analizado por PHP. Si el problema persiste, no dude en usar alguna de las múltiples opciones del <a href=\"http://www.php.net/support.php\" class=\"link external\">» Soporte para PHP</a>.</p><p>El objetivo de este ejemplo es el formato de las etiquetas especiales de PHP. En este ejemplo utilizamos <em>&lt;?php</em> para indicar el inicio de una etiqueta de PHP. Después ponemos la sentencia y abandonamos el modo PHP añadiendo la etiqueta de cierre <em>?&gt;</em>. De esta manera, se puede entrar y salir del modo PHP en un fichero HTML cada vez que se quiera. Para más información, lea la sección del manual titulada <a href=\"http://php.net/manual/es/language.basic-syntax.php\" class=\"link\">Sintaxis básica de PHP</a>.</p><blockquote><strong>Nota</strong>: <span class=\"info\"><strong>Una observación sobre los avances de línea</strong><br></span><br>Los avances de línea tienen poco sentido en HTML, aunque sigue siendo buena idea hacer que el código HTML se vea limpio y claro poniendo avances de línea. PHP automáticamente eliminará los avances de línea que estén después de una etiqueta de cierre <em>?&gt;</em>. Esto puede ser muy útil al poner muchos bloques de PHP o incluir ficheros que contienen PHP y que se supone que no deben mostrar nada. Al mismo tiempo, puede resultar un poco confuso. Se puede poner un espacio después de la etiqueta de cierre <em>?&gt;</em> para mostrar forzosamente un espacio y un avance de línea, o se puede poner un avance de línea explícito en el último echo/print dentro del bloque de PHP.<br></blockquote><blockquote><strong>Nota</strong>: <span class=\"info\"><strong>Una observación sobre los editores de texto</strong><br></span><br>Hay muchos editores de texto y Entornos de Desarrollo Integrados (IDE por sus siglas en Inglés) que se pueden emplear para crear, editar, y gestionar ficheros de PHP. Se puede encontrar una lista parcial de estos en <a href=\"http://en.wikipedia.org/wiki/List_of_PHP_editors\" class=\"link external\">» Lista de editores de PHP</a>. Si desea recomendar un editor, por favor visite la página mencionada anteriormente y pregunte al mantenedor de la página para que lo incluya en la lista. Contar con un editor que resalte la sintaxis puede ser de mucha ayuda.<br></blockquote><blockquote><strong>Nota</strong>: <span class=\"info\"><strong>Una observación sobre los procesadores de texto</strong><br></span><br>Los procesadores de texto como StarOffice Writer, Microsoft Word y Abiword no son buenas opciones para editar ficheros de PHP. Si desea utilizar uno de estos programas para probar este script, asegúrese de guardar el documento como <em>texto sin formato</em>, o de lo contrario, PHP no será capaz de leerlo y ejecutarlo.<br></blockquote><blockquote><strong>Nota</strong>: <span class=\"info\"><strong>Una observación sobre el Bloc de Notas de Windows</strong><br></span><br>Si escribe sus scripts de PHP usando el Bloc de Notas de Windows, debe asegurarse de que sus ficheros sean guardados con la extensión <var>.php</var>. (El Bloc de Notas automáticamente añade la extensión <var>.txt</var> a los ficheros a menos que siga los siguientes pasos para prevenirlo). Cuando guarde el fichero y el programa le pregunte qué nombre desea dar al fichero, entrecomille el nombre (es decir, \"<var>hola.php</var>\"). Una alternativa es hacer clic en el menú desplegable \"Documentos de Texto (*.txt)\" del cuadro de diálogo \"Guardar como\", y cambiar a la opción \"Todos los archivos (*.*)\". Aquí puede escribir el nombre del fichero sin las comillas.<br></blockquote><p>Ahora que ha creado un pequeño script de PHP que funciona correctamente, es hora de crear el script de PHP más famoso: hacer una llamada a la función <span class=\"function\"><a href=\"http://php.net/manual/es/function.phpinfo.php\" class=\"function\">phpinfo()</a></span> para obtener mucha información útil acerca de su sistema y configuración, como las <a href=\"http://php.net/manual/es/language.variables.predefined.php\" class=\"link\">variables predefinidas</a> disponibles, los módulos de PHP cargados, y los ajustes de <a href=\"http://php.net/manual/es/configuration.php\" class=\"link\">configuración</a>. Tómese algo de tiempo para revisar esta importante información.</p><div><div><p><strong>Ejemplo #2 Obtener la información del sistema desde PHP</strong></p></div><div><div><code>&lt;?php phpinfo(); ?&gt;</code></div></div></div>',1,16,NULL,NULL,'2017-07-07 12:04:14','2017-07-07 17:07:03','Primera pagina con php','primera pagina',14,5,0,-1,'COPSERVIR'),(27,'<p>Hagamos ahora algo que puede ser más útil. Vamos a comprobar qué tipo de navegador está utilizando el usuario visitante. Para hacerlo, vamos a comprobar el string del agente de usuario que el navegador envía como parte de la petición HTTP. Esta información es almacenada en una <a href=\"http://php.net/manual/es/language.variables.php\" class=\"link\">variable</a>. En PHP, las variables siempre comienzan con un signo de dólar. La variable que nos interesa ahora es<var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER[\'HTTP_USER_AGENT\']</a></var></var>.</p><blockquote><strong>Nota</strong>:<br><var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER</a></var></var> es una variable especial reservada por PHP que contiene toda la información del servidor web. Es conocida como una superglobal. Consulte la página del manual sobre <a href=\"http://php.net/manual/es/language.variables.superglobals.php\" class=\"link\">Superglobales</a> para más información. Estas variables especiales fueron introducidas en la versión <a href=\"http://www.php.net/releases/4_1_0.php\" class=\"link external\">» 4.1.0</a> de PHP. Antes se podían usar en su lugar los antiguos arrays <var><var>$HTTP_*_VARS</var></var>, tales como <var><var>$HTTP_SERVER_VARS</var></var>. A partir de PHP 5.4.0, estos antiguos arrays han sido eliminados. (Véase también la nota sobre <a href=\"http://php.net/manual/es/tutorial.oldcode.php\" class=\"link\">código antiguo</a>).<br></blockquote><p>Para mostrar esta variable, se puede hacer simplemente:</p><div><div><p><strong>Ejemplo #1 Imprimir una variable (elemento de array)</strong></p></div><div><div><code>&lt;?php<br>echo $_SERVER[\'HTTP_USER_AGENT\'];<br>?&gt;</code></div></div><div><p>Un ejemplo del resultado de este script podría ser:</p></div><div><br>Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)<br></div></div><p>Hay muchos <a href=\"http://php.net/manual/es/language.types.php\" class=\"link\">tipos</a> de variables en PHP. En el ejemplo anterior se muestra un elemento de un <a href=\"http://php.net/manual/es/language.types.array.php\" class=\"link\">Array</a>. Los arrays pueden ser muy útiles.</p><p><var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER</a></var></var> es simplemente una variable que se encuentra disponible automáticamente en PHP. Se puede encontrar una lista en la sección <a href=\"http://php.net/manual/es/reserved.variables.php\" class=\"link\">Variables reservadas</a> del manual, o se puede obtener una lista completa observando la salida de la función <span class=\"function\"><a href=\"http://php.net/manual/es/function.phpinfo.php\" class=\"function\">phpinfo()</a></span> usada en el ejemplo de la sección anterior.</p><p>Puede usar múltiples sentencias de PHP dentro de una etiqueta de PHP y crear pequeños bloques de código que realicen más que un simple \'echo\'. Por ejemplo, si se quisiera detectar el uso de Internet Explorer, se podría hacer algo así:</p><div><div><p><strong>Ejemplo #2 Ejemplo usando <a href=\"http://php.net/manual/es/language.control-structures.php\" class=\"link\">estructuras de control</a> y <a href=\"http://php.net/manual/es/language.functions.php\" class=\"link\">funciones</a></strong></p></div><div><div><code>&lt;?php<br>if (strpos($_SERVER[\'HTTP_USER_AGENT\'], \'MSIE\') !== FALSE) {<br>    echo \'Está usando Internet Explorer.&lt;br /&gt;\';<br>}<br>?&gt;</code></div></div><div><p>Un ejemplo del resultado de este script sería:</p></div><div><div><pre>Está usando Internet Explorer.&lt;br /&gt;\r\n</pre></div></div></div><p>Aquí hemos introducido un par de conceptos nuevos. Tenemos una sentencia <a href=\"http://php.net/manual/es/control-structures.if.php\" class=\"link\">if</a>. Si está familiarizado con la sintaxis básica del lenguaje C, debería parecerle lógico. De lo contrario, probablemente debería conseguir un libro que le introduzca a PHP, y leer el primer par de capítulos, o leer la parte del manual titulada <a href=\"http://php.net/manual/es/langref.php\" class=\"link\">Referencia del lenguaje</a>.</p><p>El segundo concepto que introducimos fue la función llamada a <span class=\"function\"><a href=\"http://php.net/manual/es/function.strpos.php\" class=\"function\">strpos()</a></span>. <span class=\"function\"><a href=\"http://php.net/manual/es/function.strpos.php\" class=\"function\">strpos()</a></span>es una función integrada en PHP que busca un string dentro de otro. En este caso estamos buscando <em>\'MSIE\'</em> (también llamado aguja) dentro de<var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER[\'HTTP_USER_AGENT\']</a></var></var> (también llamado pajar). Si el string se encuentra dentro del pajar, la función devuelve la posición de la aguja relativa al inicio del pajar. De lo contrario, devuelve <strong><code>FALSE</code></strong>. Si no devuelve <strong><code>FALSE</code></strong>, la expresión <a href=\"http://php.net/manual/es/control-structures.if.php\" class=\"link\">if</a> se evalúa como <strong><code>TRUE</code></strong> y se ejecuta el código entre llaves {}. De lo contrario, el código no será ejecutado. Tómese la libertad de crear ejemplos similares, con <a href=\"http://php.net/manual/es/control-structures.if.php\" class=\"link\">if</a>, <a href=\"http://php.net/manual/es/control-structures.else.php\" class=\"link\">else</a>, y otras funciones como <span class=\"function\"><a href=\"http://php.net/manual/es/function.strtoupper.php\" class=\"function\">strtoupper()</a></span> y <span class=\"function\"><a href=\"http://php.net/manual/es/function.strlen.php\" class=\"function\">strlen()</a></span>. Cada página del manual relacionada también contiene ejemplos. Si no está seguro de cómo usar estas funciones, es recomendable que lea las páginas del manual sobre <a href=\"http://php.net/manual/es/about.prototypes.php\" class=\"link\">Cómo interpretar una definición de función</a> y la sección sobre <a href=\"http://php.net/manual/es/language.functions.php\" class=\"link\">Funciones de PHP</a>.</p><p>Podemos dar un paso más y mostrar cómo se puede entrar y salir del modo PHP incluso en medio de un bloque de código de PHP:</p><div><div><p><strong>Ejemplo #3 Mezcla de los modos HTML y PHP</strong></p></div><div><div><code>&lt;?php<br>if (strpos($_SERVER[\'HTTP_USER_AGENT\'], \'MSIE\') !== FALSE) {<br>?&gt;<br>&lt;h3&gt;strpos() debe haber devuelto no falso&lt;/h3&gt;<br>&lt;p&gt;Está usando Internet Explorer&lt;/p&gt;<br>&lt;?php<br>} else {<br>?&gt;<br>&lt;h3&gt;strpos() debe haber devuelto falso&lt;/h3&gt;<br>&lt;p&gt;No está usando Internet Explorer&lt;/p&gt;<br>&lt;?php<br>}<br>?&gt;</code></div></div><div><p>Un ejemplo del resultado del script podría ser:</p></div><div><div><pre>&lt;h3&gt;strpos() debe haber devuelto no falso&lt;/h3&gt;\r\n&lt;p&gt;Está usando Internet Explorer&lt;/p&gt;\r\n</pre></div></div></div><p>En vez de usar una sentencia echo de PHP para mostrar algo, salimos del modo PHP y enviamos solamente HTML. Este es un punto muy importante y potente que se ha de observar aquí, y es que la fluidez lógica del script permanece intacta. Solamente uno de los bloques HTML terminará siendo enviado al navegador dependiendo del resultado de <span class=\"function\"><a href=\"http://php.net/manual/es/function.strpos.php\" class=\"function\">strpos()</a></span>. En otras palabras, depende de si el string <em>MSIE</em> fue encontrada o no.</p>',1,16,NULL,NULL,'2017-07-07 12:04:47','2017-07-07 17:07:30','Algo util','Algo util',14,5,0,-1,'COPSERVIR'),(28,'<p>Otra de las características más potentes de PHP es la forma de gestionar formularios HTML. El concepto básico que es importante entender es que cualquier elemento de un formulario estará disponible automáticamente en sus scripts de PHP. Por favor, lea la sección del manual sobre <a href=\"http://php.net/manual/es/language.variables.external.php\" class=\"link\">Variables desde fuentes externas</a> para obtener más información y ejemplos sobre cómo usar formularios con PHP. Observemos un ejemplo:</p><div><div><p><strong>Ejemplo #1 Un formulario HTML sencillo</strong></p></div><div><div><pre>&lt;form action=\"accion.php\" method=\"post\"&gt;\r\n &lt;p&gt;Su nombre: &lt;input type=\"text\" name=\"nombre\" /&gt;&lt;/p&gt;\r\n &lt;p&gt;Su edad: &lt;input type=\"text\" name=\"edad\" /&gt;&lt;/p&gt;\r\n &lt;p&gt;&lt;input type=\"submit\" /&gt;&lt;/p&gt;\r\n&lt;/form&gt;</pre></div></div></div><p>No hay nada especial en este formulario. Es solamente un formulario HTML sin ninguna clase de etiqueta especial. Cuando el usuario rellena este formulario y oprime el botón de envío, se llama a la página <var>accion.php</var>. En este fichero se podría escribir algo así:</p><div><div><p><strong>Ejemplo #2 Mostrar información de nuestro formulario</strong></p></div><div><div><code>Hola &lt;?php echo htmlspecialchars($_POST[\'nombre\']); ?&gt;.<br>Usted tiene &lt;?php echo (int)$_POST[\'edad\']; ?&gt; años.</code></div></div><div><p>Un ejemplo del resultado de este script podría ser:</p></div><div><div><pre>Hola José. Usted tiene 22 años.\r\n</pre></div></div></div><p>Excepto las partes de <span class=\"function\"><a href=\"http://php.net/manual/es/function.htmlspecialchars.php\" class=\"function\">htmlspecialchars()</a></span> y de <em>(int)</em>, debería ser obvio qué es lo que hace el código. <span class=\"function\"><a href=\"http://php.net/manual/es/function.htmlspecialchars.php\" class=\"function\">htmlspecialchars()</a></span> garantiza que cualquier carácter que sea especial en html se codifique adecuadamente, de manera que nadie pueda inyectar etiquetas HTML o Javascript en la página. El campo edad, ya que sabemos que es un número, podemos <a href=\"http://php.net/manual/es/language.types.type-juggling.php#language.types.typecasting\" class=\"link\">convertirlo</a> a un valor de tipo <span class=\"type\"><a href=\"http://php.net/manual/es/language.types.integer.php\" class=\"type integer\">integer</a></span> que automáticamente se deshará de cualquier carácter no numérico. También se puede hacer lo mismo con PHP con la extensión <a href=\"http://php.net/manual/es/ref.filter.php\" class=\"link\">filter</a>. Las variables <var><var><a href=\"http://php.net/manual/es/reserved.variables.post.php\" class=\"classname\">$_POST[\'nombre\']</a></var></var> y <var><var><a href=\"http://php.net/manual/es/reserved.variables.post.php\" class=\"classname\">$_POST[\'edad\']</a></var></var> son establecidas automáticamente por PHP. Anteriormente hemos usado la superglobal <var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER</a></var></var>; arriba introdujimos la superglobal <var><var><a href=\"http://php.net/manual/es/reserved.variables.post.php\" class=\"classname\">$_POST</a></var></var>, la cual contiene todos los datos de POST. Observe que el<em>método</em> de nuestro formulario es POST. Si hubiésemos usado el método <em>GET</em>, nuestra información estaría en su lugar en la superglobal <var><var><a href=\"http://php.net/manual/es/reserved.variables.get.php\" class=\"classname\">$_GET</a></var></var>. También se podría usar la superglobal <var><var><a href=\"http://php.net/manual/es/reserved.variables.request.php\" class=\"classname\">$_REQUEST</a></var></var>, si no le preocupa la fuente de los datos solicitados. Contiene toda la información de los datos de GET, POST y COOKIE mezclada.</p><p>En PHP, también puede tratar con entradas de XForms; aunque probablemente al principio se sienta cómodo con los formularios de HTML, los cuales están ampliamente respaldados. A pesar de que trabajar con XForms no es para principiantes, podrían interesarle. Si es así, en la sección de características hay una <a href=\"http://php.net/manual/es/features.xforms.php\" class=\"link\">pequeña introducción a la manipulación de datos recibidos desde XForms</a>.</p>',1,16,NULL,NULL,'2017-07-07 12:05:23','2017-07-07 17:08:15','Tratar con formularios','Tratar con formularios',14,10,0,-1,'COPSERVIR'),(29,'<p>Ahora que PHP ha crecido y se ha convertido en un lenguaje popular, hay muchos más repositorios y bibliotecas que contienen código que puede reutilizar. Los desarrolladores de PHP han intentado preservar la retrocompatibilidad, es decir, si un script fue escrito para una versión antigua, funcionará (idealmente) sin ningún cambio en una versión reciente de PHP. En la práctica, normalmente son necesarios algunos cambios.</p><p>Dos de los cambios más importantes que afectan el código antiguo son:</p><ul><li><span class=\"simpara\">Los antiguos arrays <var><var>$HTTP_*_VARS</var></var> ya no están disponibles a partir de PHP 5.4.0. Los siguientes <a href=\"http://php.net/manual/es/language.variables.superglobals.php\" class=\"link\">arrays superglobales</a> fueron introducidos en PHP <a href=\"http://www.php.net/releases/4_1_0.php\" class=\"link external\">» 4.1.0</a>. Son: <var><var><a href=\"http://php.net/manual/es/reserved.variables.get.php\" class=\"classname\">$_GET</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.post.php\" class=\"classname\">$_POST</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.cookies.php\" class=\"classname\">$_COOKIE</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.server.php\" class=\"classname\">$_SERVER</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.files.php\" class=\"classname\">$_FILES</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.environment.php\" class=\"classname\">$_ENV</a></var></var>, <var><var><a href=\"http://php.net/manual/es/reserved.variables.request.php\" class=\"classname\">$_REQUEST</a></var></var>, y <var><var><a href=\"http://php.net/manual/es/reserved.variables.session.php\" class=\"classname\">$_SESSION</a></var></var>.</span></li><li><span class=\"simpara\">Las variables externas ya no son registradas en el ámbito global de forma predeterminada. En otras palabras, a partir de PHP <a href=\"http://www.php.net/releases/4_2_0.php\" class=\"link external\">» 4.2.0</a>, la directiva de PHP<a href=\"http://php.net/manual/es/ini.core.php#ini.register-globals\" class=\"link\">register_globals</a> está desactivada (<em>off</em>) por defecto en <var>php.ini</var>. El mejor método para acceder a estos valores es por medio de las variables superglobales mencionadas anteriormente. Los scripts, libros y tutoriales antiguos podrían contar con que esta directiva esté activada (<em>on</em>). Si fuera <em>on</em>, por ejemplo, se podría usar <var><var>$id</var></var> desde el URL<em><a href=\"http://www.example.com/foo.php?id=42\">http://www.example.com/foo.php?id=42</a></em>. Ya esté activada o desactivada, <var><var><a href=\"http://php.net/manual/es/reserved.variables.get.php\" class=\"classname\">$_GET[\'id\']</a></var></var> está siempre disponible.</span></li></ul>Para más información relacionada con estos cambios, véase la sección sobre<a href=\"http://php.net/manual/es/language.variables.predefined.php\" class=\"link\">variables predefinidas</a> y los enlaces que incluye.',1,16,NULL,NULL,'2017-07-07 12:05:50','2017-07-07 17:08:44','Utilizar código antiguo en nuevas versiones de PHP','Utilizar código antiguo en nuevas versiones de PHP',14,5,0,-1,'COPSERVIR'),(30,'',1,2,NULL,NULL,'2017-07-07 16:32:57','2017-07-07 21:34:14','Prueba puntos','prueba',4,10,20,6,'ALLERGAN DE COLOMBIA S A');
/*!40000 ALTER TABLE `m_FORCO_Contenido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Cuestionario`
--

DROP TABLE IF EXISTS `m_FORCO_Cuestionario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Cuestionario` (
  `idCuestionario` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tituloCuestionario` varchar(100) NOT NULL,
  `descripcionCuestionario` varchar(250) NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `porcentajeMinimo` int(11) NOT NULL DEFAULT '0',
  `numeroPreguntas` int(11) NOT NULL DEFAULT '0',
  `numeroIntentos` int(11) NOT NULL DEFAULT '0',
  `idCurso` int(10) unsigned DEFAULT NULL,
  `tiempo` int(11) NOT NULL,
  `idContenido` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`idCuestionario`),
  KEY `idCurso` (`idCurso`),
  KEY `idContenido` (`idContenido`),
  CONSTRAINT `m_FORCO_Cuestionario_ibfk_1` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`) ON UPDATE CASCADE,
  CONSTRAINT `m_FORCO_Cuestionario_ibfk_2` FOREIGN KEY (`idContenido`) REFERENCES `m_FORCO_Contenido` (`idContenido`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Cuestionario`
--

LOCK TABLES `m_FORCO_Cuestionario` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Cuestionario` DISABLE KEYS */;
INSERT INTO `m_FORCO_Cuestionario` VALUES (1,'Estadistica','<p \"=\"\">Inicios y bases sobre estadistica descriptiva.<br></p>',1,'2017-03-03 09:07:58','2017-07-06 15:41:32',100,6,20,11,1,NULL),(4,'Cuestionario','<p style=\"margin-left: 20px;\">Cuestionario de preguntas de fútbol<br></p>',1,'2017-03-15 04:51:05','2017-04-04 21:28:57',70,5,4,5,0,NULL),(5,'Cuestionario de programación','<p style=\"margin-left: 20px;\">Cuestionario de programación de c++ y fundamentos de lenguajes en nivel básico<br></p>',1,'2017-04-06 10:22:17','2017-04-06 20:07:20',70,5,5,8,0,NULL),(6,'Curso 2','<p style=\"margin-left: 20px;\">Curso</p>',1,'2017-05-12 09:20:41','2017-05-12 14:20:41',60,3,3,11,10,NULL),(7,'EISO','<p \"=\"\">Cuestionario sobre EISO</p>',1,'2017-06-07 03:32:15','2017-06-07 08:32:15',50,3,3,11,20,NULL),(8,'fasdfasdf','<p>asdfadsf</p>',1,'2017-06-14 10:50:15','2017-06-14 15:50:15',60,10,2,11,10,NULL),(9,'Cuestionario 1','<p>Cuestionario 1</p>',1,'2017-06-14 11:04:01','2017-06-14 16:04:01',60,10,3,12,5,NULL),(10,'Induccion de mensajeros','<p \"=\"\">Induccion de mensajeros</p>',1,'2017-07-06 11:53:23','2017-07-06 17:06:58',20,2,3,12,5,19),(11,'Induccion de mensajeros','<p>Induccion a mensajeros<br></p>',1,'2017-07-06 12:10:25','2017-07-06 17:10:25',50,2,3,12,4,20),(12,'Induccion de mensajeros','<p>Cuestionario 3<br></p>',1,'2017-07-06 12:14:54','2017-07-06 17:14:54',5,2,3,12,4,21),(13,'Induccion de mensajeros Toda la unidad','<p>Induccion de mensajeros Toda la unidad</p>',1,'2017-07-06 12:22:57','2017-07-06 17:22:57',60,4,3,12,10,NULL),(14,'?Que es php','<p>Que es php<br></p>',1,'2017-07-07 12:19:46','2017-07-07 17:19:46',100,1,1,14,1,23),(15,'Php 2','<p>Php 2<br></p>',1,'2017-07-07 02:48:31','2017-07-07 07:48:31',100,1,3,14,1,24),(16,'Que se necesita?','<p>Que se necesita?</p>',1,'2017-07-07 02:50:52','2017-07-07 07:50:52',100,1,2,14,1,25),(17,'primera pagina','<p \"=\"\">Primera pagina</p>',1,'2017-07-07 02:55:19','2017-07-07 07:55:19',100,1,2,14,2,26),(18,'Algo util','<p style=\"margin-left: 20px;\">Algo util<br></p>',1,'2017-07-07 02:59:31','2017-07-07 07:59:31',100,1,1,14,1,27),(19,'Formularios','<p style=\"margin-left: 20px;\">Formularios</p>',1,'2017-07-07 03:02:55','2017-07-07 08:02:55',10,1,1,14,1,28),(20,'codigo antiguo','codigo antiguo<br>',1,'2017-07-07 03:07:29','2017-07-07 08:07:29',100,1,1,14,1,29),(21,'Cuestionario de la unidad','<p>Cuestionario de la unidad de php<br></p>',1,'2017-07-07 03:11:09','2017-07-07 08:11:09',70,5,3,14,5,NULL);
/*!40000 ALTER TABLE `m_FORCO_Cuestionario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Curso`
--

DROP TABLE IF EXISTS `m_FORCO_Curso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Curso` (
  `idCurso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombreCurso` varchar(45) DEFAULT NULL,
  `presentacionCurso` varchar(250) DEFAULT NULL,
  `estadoCurso` tinyint(1) NOT NULL DEFAULT '1',
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fechaInicio` datetime NOT NULL,
  `fechaFin` datetime DEFAULT NULL,
  `tipoCurso` tinyint(1) NOT NULL DEFAULT '1',
  `rutaImagen` varchar(100) DEFAULT NULL,
  `promedioCalificacion` float NOT NULL DEFAULT '0',
  `fechaActivacion` datetime DEFAULT NULL,
  `cantidadPuntos` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idCurso`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Curso`
--

LOCK TABLES `m_FORCO_Curso` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Curso` DISABLE KEYS */;
INSERT INTO `m_FORCO_Curso` VALUES (4,'Desembolsemos el planeta','Desembolsemos el planeta',0,'2017-03-27 12:29:56','2017-07-07 15:18:50','2017-03-29 00:00:00','2017-04-12 00:00:00',1,'1497452648_.png',4,NULL,20),(5,'Curso 2','Prueba 2',1,'2017-03-29 11:27:53','2017-07-07 15:19:56','2017-03-29 00:00:00','0000-00-00 00:00:00',1,'1494942754_.jpg',0,NULL,0),(6,'curso 3','blablablabla',1,'2017-03-29 11:29:57','2017-06-21 19:50:53','2017-03-01 00:00:00','2017-03-01 00:00:00',1,'1494942754_.jpg',0,NULL,0),(7,'Prueba','Pruena select',0,'2017-03-29 15:43:51','2017-05-26 21:35:37','2017-03-30 00:00:00','0000-00-00 00:00:00',0,'1494942754_.jpg',0,NULL,0),(8,'C++','Curso de introduccion a c++',1,'2017-04-06 10:09:36','2017-06-21 19:45:45','2017-04-26 00:00:00','2017-04-29 00:00:00',0,'1494942754_.jpg',5,NULL,0),(9,'Prueba','Prueba despues de la embarrada con las versiones',1,'2017-04-28 15:32:26','2017-06-21 19:46:49','2017-04-01 00:00:00','2017-04-13 00:00:00',0,'1494942754_.jpg',4,NULL,0),(10,'Prueba','asdf',1,'2017-04-28 12:27:11','2017-07-07 15:20:06','2017-04-12 00:00:00',NULL,1,'1494942754_.jpg',0,NULL,0),(11,'Modelo de Servicio para clientes más felices','Presentación del Modelo de servicio',1,'2017-05-05 10:42:18','2017-07-06 13:16:22','2017-05-04 00:00:00','2017-07-10 00:00:00',1,'1494942754_.jpg',0,NULL,0),(12,'Inducción especifica mensajeros','Inducción especifica mensajeros',0,'2017-06-14 09:12:25','2017-07-06 19:13:25','2017-06-13 00:00:00','2017-07-23 00:00:00',1,'1497449545_.png',0,NULL,0),(13,'Prueba','Prueba',0,'2017-07-06 14:01:18','2017-07-06 19:00:54','2017-07-01 00:00:00',NULL,1,NULL,0,NULL,20),(14,'Programación de php','Este curso está enfocado para aquellos programadores que quieran iniciar sus bases en programación de php para trabajar en copservir',1,'2017-07-07 11:41:49','2017-07-07 17:16:54','2017-07-07 00:00:00','2017-07-10 00:00:00',1,NULL,0,NULL,100);
/*!40000 ALTER TABLE `m_FORCO_Curso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Modulo`
--

DROP TABLE IF EXISTS `m_FORCO_Modulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Modulo` (
  `idModulo` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombreModulo` varchar(45) NOT NULL,
  `descripcionModulo` varchar(250) NOT NULL,
  `estadoModulo` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `idCurso` int(10) unsigned NOT NULL,
  `duracionDias` int(3) unsigned NOT NULL,
  `fechaInicio` datetime DEFAULT NULL,
  `fechaFin` datetime DEFAULT NULL,
  PRIMARY KEY (`idModulo`),
  KEY `fk_m_FORCO_Modulo_m_FORCO_Curso` (`idCurso`),
  CONSTRAINT `fk_m_FORCO_Modulo_m_FORCO_Curso` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Modulo`
--

LOCK TABLES `m_FORCO_Modulo` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Modulo` DISABLE KEYS */;
INSERT INTO `m_FORCO_Modulo` VALUES (2,'Modulo 1','Reglamento interno',1,'2017-03-27 14:28:53','2017-03-29 23:17:49',4,10,'2017-03-29 00:00:00','2017-04-08 00:00:00'),(3,'Modulo 2','Prueba con duracion',1,'2017-03-29 10:35:18','2017-03-29 23:17:21',4,4,'2017-04-08 00:00:00','2017-04-12 00:00:00'),(4,'modulo 1','blablablabla',1,'2017-03-29 11:31:33','2017-06-21 19:47:07',6,0,'2017-03-01 00:00:00','2017-03-01 00:00:00'),(5,'Tipos de datos','Tipos de datos',1,'2017-04-06 10:11:26','2017-04-06 16:26:55',8,20,'2017-04-06 00:00:00','2017-04-26 00:00:00'),(6,'Modulo 1','Modulo',1,'2017-04-19 15:34:20','2017-04-19 20:35:34',9,10,'2017-04-01 00:00:00','2017-04-11 00:00:00'),(7,'Modulo 2','asdf',1,'2017-04-19 15:34:35','2017-04-19 20:35:34',9,2,'2017-04-11 00:00:00','2017-04-13 00:00:00'),(8,'Modulo 1','Modulo 1',1,'2017-05-05 10:47:37','2017-07-07 16:24:37',11,60,'2017-05-04 00:00:00','2017-07-03 00:00:00'),(9,'Modulo 1','Modulo 1',1,'2017-06-14 09:13:00','2017-06-14 14:47:55',12,20,'2017-06-13 00:00:00','2017-07-03 00:00:00'),(10,'Modulo 2','Modulo 2',1,'2017-06-14 09:24:47','2017-06-14 14:47:55',12,20,'2017-07-03 00:00:00','2017-07-23 00:00:00'),(11,'Modulo 2','Modulo',1,'2017-07-06 10:49:04','2017-07-07 20:17:47',11,10,NULL,NULL),(12,'Introducción','Introducción a las bases para trabajar en php',1,'2017-07-07 11:42:50','2017-07-07 20:17:47',14,3,NULL,NULL);
/*!40000 ALTER TABLE `m_FORCO_Modulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_OpcionRespuesta`
--

DROP TABLE IF EXISTS `m_FORCO_OpcionRespuesta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_OpcionRespuesta` (
  `idOpcionRespuesta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idPregunta` int(10) unsigned NOT NULL,
  `respuesta` varchar(250) NOT NULL,
  `esCorrecta` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idOpcionRespuesta`),
  KEY `fk_m_FORCO_OpcionRespuesta_m_FORCO_Pregunta1_idx` (`idPregunta`),
  CONSTRAINT `fk_m_FORCO_OpcionRespuesta_m_FORCO_Pregunta1` FOREIGN KEY (`idPregunta`) REFERENCES `m_FORCO_Pregunta` (`idPregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=212 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_OpcionRespuesta`
--

LOCK TABLES `m_FORCO_OpcionRespuesta` WRITE;
/*!40000 ALTER TABLE `m_FORCO_OpcionRespuesta` DISABLE KEYS */;
INSERT INTO `m_FORCO_OpcionRespuesta` VALUES (2,1,'0.25',0),(3,1,'0.500',1),(4,1,'0.75',0),(6,1,'1',0),(7,2,'0.25',0),(8,2,'0.14',0),(9,2,'0.11',1),(10,2,'0.2',0),(11,3,'0.26585',0),(12,3,'0.65512',0),(13,3,'0.82800',1),(14,3,'0.86321',0),(15,4,'220',1),(16,4,'225',0),(17,4,'230',0),(18,4,'235',0),(19,5,'0.482',1),(20,5,'0.400',0),(21,5,'0.453',0),(22,5,'0.495',0),(23,6,'Discreta',0),(24,6,'Cualitativa',0),(25,6,'Cuantitativa',0),(26,6,'Continua',1),(27,7,'5.8    5.5   5 y 6',1),(28,7,'5.9    5.7   5',0),(29,7,'5.8    5.6   6',0),(31,7,'5.9    5.5    5 y 6',0),(32,8,'1/36',0),(33,8,'6/36',1),(34,8,'1/2',0),(35,8,'4/12',0),(37,9,'4/52',1),(38,9,'3/52',1),(39,9,'8/52',0),(40,9,'1/52',0),(41,10,'1.22774*10^-6',0),(42,10,'1.22774*10^-7',1),(43,10,'1.22774*10^-8',0),(44,10,'1.22774*10^-9',0),(45,11,'La varianza de una muestra siempre se divide por el número de datos.',0),(46,11,'La varianza de una muestra siempre se divide por el número de datos y restandole uno.',1),(47,11,'El coeficiente de variación puede ser mayor a 100%',1),(48,11,'¿La media geométrica consiste en sumar los valores y dividirlos sobre la raiz cuadrada del número de datos?',0),(51,12,'Verdadero',1),(52,12,'Falso',0),(53,13,'20',0),(54,13,'9.8',1),(55,13,'11',0),(56,13,'5',0),(57,14,'2 + 2 es 4',1),(58,14,'Sqrt(5) es 2.5',0),(59,14,'Log(e) es 0',0),(60,16,'Verdadero',0),(61,16,'Falso',1),(62,19,'monaco',1),(63,19,'bayern munich',1),(64,19,'real madrid',1),(65,20,'alemania',1),(66,20,'España',1),(67,20,'Italia',1),(68,20,'Brasil',1),(69,19,'barcelona',1),(70,21,'Brasil',0),(71,21,'Argentina',0),(72,21,'Italia',0),(73,21,'España',0),(74,21,'Alemania',0),(75,21,'Uruguay',1),(76,22,'Italia',0),(77,22,'Alemania',0),(78,22,'Brasil',1),(79,22,'Uruguay',0),(80,22,'Argentina',0),(81,23,'Bolivia',0),(83,23,'Venezuela',1),(84,23,'Nueva Zelanda',0),(85,23,'Canada',0),(86,24,'Brasil',0),(87,24,'Sudafrica',1),(88,24,'Mexico',0),(89,24,'Japón',0),(90,24,'Corea del sur',0),(91,24,'Chile',0),(92,25,'Thomas Müller',0),(94,25,'James Rodriguez',1),(95,25,'Lionel Messi',0),(96,25,'Neymar Jr.',0),(97,25,'Cristiano Ronaldo',0),(98,26,'Argentina nunca habia recibido mas de 3 goles en un mundial',0),(99,26,'El campeón defensor era eliminado en fase de grupos',0),(100,26,'España sería campeón siendo el primer Europeo en ganar fuera de su continente',1),(101,26,'Fue el mundial con muchos goles en fases de grupo',0),(102,27,'Chile 1962',0),(103,27,'Italia 1990',1),(104,27,'Estados Unidos 1994',0),(105,27,'Francia 1998',0),(106,28,'Ecuador ganaría su primer partido en un mundial',0),(107,28,'Sería dirigido por dos tecnicos Colombianos, quienes dirigieron a las selecciones rivales en mundiales pasados',1),(108,28,'No hubo asistencia en el estadio, dado por protestas realizadas por los brasileños a las afueras del estadio. ',0),(109,28,'Fue el partido con más expulsados en la copa mundial.',0),(110,29,'Brasil',1),(111,29,'Italia',1),(112,29,'España',0),(113,29,'Argentina',0),(114,29,'Alemania',1),(115,29,'Uruguay',0),(116,29,'Inglaterra',0),(117,30,'Robben',0),(118,30,'Messi',0),(119,30,'Forlan',1),(120,30,'Sneijder',1),(121,30,'Thomas Müller',1),(122,30,'Schweinsteiger',0),(123,31,'16',1),(124,31,'8',0),(125,31,'14',0),(126,31,'15',0),(127,32,'Verdadero',1),(128,32,'Falso',0),(129,33,'HTML',1),(130,33,'C#',0),(131,33,'CSS',1),(132,33,'JAVA ME',0),(133,33,'JAVA SE',0),(134,34,'a',1),(135,34,'b',0),(136,34,'c',0),(137,36,'A',1),(138,36,'b',0),(139,36,'c',0),(140,36,'d',0),(141,38,'C',1),(142,39,'B',1),(143,41,'Satisfacer necesidades usuarios',1),(144,41,'Tener al cliente lo que no pertenece',0),(145,41,'Vender a usuarios productos mas costosos',0),(146,42,'Satisfacer necesidades del cliente',1),(147,42,'Los clientes deben conocer que productos tienen a su poder',0),(148,42,'A clientes que compren mas debe atenderse mejor que los otros',0),(149,43,'Los objetivos no estan en el alcance',0),(150,43,'Tener en cuenta horarios extendidos para brindar mejor atención',0),(151,43,'Ser amable con el cliente y atender todas sus necesidades',1),(152,44,'Isabella',0),(153,44,'Juan Sebastian',0),(154,44,'Juan Jose',1),(155,44,'Miguel',0),(156,46,'web',1),(157,47,'fddfdfdfdfdf',0),(158,47,'sfdasfdaf',1),(159,48,'las 10am',0),(160,48,'las 08am',0),(161,48,'las 11am',1),(162,49,'Verdadero',1),(163,49,'Falso',0),(164,51,'lunes',1),(165,51,'monday',1),(166,52,'11am',1),(167,52,'11',1),(168,52,'once',1),(169,53,'Administrativo?',0),(170,53,'Envia mensajes',0),(171,53,'Hace entrega de los domicilios',1),(172,54,'Un pasaporte',0),(173,54,'Una moto ',1),(174,54,'Una bicicleta de tracción',0),(175,55,'Seguro, moto, uniforme',1),(176,55,'Moto, pasaporte, documentacion',0),(177,55,'Cartas, esferos, computadoras',0),(178,56,'Verdadero',1),(179,56,'Falso',0),(180,57,'siicop',0),(181,57,'servicios solidarios',1),(182,57,'seria',0),(183,58,'Verdadero',0),(184,58,'Falso',1),(185,59,'es un lenguaje de código abierto muy popular especialmente adecuado para el desarrollo web y que puede ser incrustado en HTML.',1),(186,59,'es un lenguaje de código abierto muy popular especialmente adecuado para el desarrollo web y que puede ser incrustado en JAVA',0),(187,59,'es un lenguaje de código abierto muy popular especialmente adecuado para el desarrollo web y que puede ser incrustado en C.',0),(188,60,'Verdadero',0),(189,60,'Falso',1),(190,61,'exe',0),(191,61,'htaccess',0),(192,61,'js',0),(193,61,'php',1),(194,61,'ajax',0),(195,61,'java',0),(196,62,'Error de sintaxis',0),(197,62,'Hola mundo',1),(198,62,'<p>Hola Mundo</p>',0),(199,62,'\'<p>Hola Mundo</p>\'',0),(200,64,'dolar',1),(201,64,'dólar',1),(202,64,'$',1),(203,64,'pesos',1),(204,65,'radio',1),(205,65,'label',0),(206,65,'text',1),(207,65,'submit',1),(208,65,'delete',0),(209,66,'$_GET, $_POST,$_COOKIE, $_SERVER, $_FILES, $_ENV, $_REQUEST, y $_SESSION.',1),(210,66,'$_JSON, $_REQUEST, $_POST',0),(211,66,'$_HTTP_REQUEST, $_LOCAL_SERVER, $_SESSION',0);
/*!40000 ALTER TABLE `m_FORCO_OpcionRespuesta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_ParametrosPuntos`
--

DROP TABLE IF EXISTS `m_FORCO_ParametrosPuntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_ParametrosPuntos` (
  `idParametroPunto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoParametro` int(1) unsigned NOT NULL,
  `valorPuntos` int(11) unsigned NOT NULL,
  `condicion` int(2) unsigned DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `valorPuntosExtra` int(11) DEFAULT NULL,
  PRIMARY KEY (`idParametroPunto`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_ParametrosPuntos`
--

LOCK TABLES `m_FORCO_ParametrosPuntos` WRITE;
/*!40000 ALTER TABLE `m_FORCO_ParametrosPuntos` DISABLE KEYS */;
INSERT INTO `m_FORCO_ParametrosPuntos` VALUES (4,2,200,1,1,NULL,'2017-07-05 21:09:14',NULL),(5,2,300,2,1,NULL,'2017-07-05 21:09:14',NULL),(6,2,300,2,1,NULL,'2017-07-05 21:09:14',NULL);
/*!40000 ALTER TABLE `m_FORCO_ParametrosPuntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Pregunta`
--

DROP TABLE IF EXISTS `m_FORCO_Pregunta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Pregunta` (
  `idPregunta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tituloPregunta` varchar(45) NOT NULL,
  `pregunta` text,
  `idPreguntaPadre` int(10) unsigned DEFAULT NULL COMMENT 'Para agrupar preguntas (completar)',
  `idTipoPregunta` int(10) unsigned NOT NULL,
  `idCuestionario` int(10) unsigned NOT NULL,
  `estado` tinyint(1) unsigned NOT NULL,
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`idPregunta`),
  KEY `fk_m_FORCO_Pregunta_m_FORCO_Pregunta1_idx` (`idPreguntaPadre`),
  KEY `fk_m_FORCO_Pregunta_m_TipoPregunta1_idx` (`idTipoPregunta`),
  KEY `fk_m_FORCO_Pregunta_m_FORCO_Cuestionario1_idx` (`idCuestionario`),
  CONSTRAINT `fk_m_FORCO_Pregunta_m_FORCO_Cuestionario1` FOREIGN KEY (`idCuestionario`) REFERENCES `m_FORCO_Cuestionario` (`idCuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_m_FORCO_Pregunta_m_FORCO_Pregunta1` FOREIGN KEY (`idPreguntaPadre`) REFERENCES `m_FORCO_Pregunta` (`idPregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_m_FORCO_Pregunta_m_TipoPregunta1` FOREIGN KEY (`idTipoPregunta`) REFERENCES `m_FORCO_TipoPregunta` (`idTipoPregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Pregunta`
--

LOCK TABLES `m_FORCO_Pregunta` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Pregunta` DISABLE KEYS */;
INSERT INTO `m_FORCO_Pregunta` VALUES (1,'Pregunta 1','<p>Si tienes una moneda legal (2 caras), cual es la probabilidad de que salga la misma cara, si se tiran dos veces.</p>',NULL,1,1,1,'2017-03-21 11:37:43','2017-03-21 16:38:49'),(2,'Pregunta 2','<p>Los archivos importantes de una oficina de consultoría son manejados por Juanita(50%), Lupita(30%) y Rosita(20%). El director de la oficina ha estimado probabilidades “a priori”, para cada una de ellas, de que pierdan o traspapelen un informe en los porcentajes: 15, 5 y 10% respectivamente. ¿ Cuál es la probabilidad total de que un informe llegue a perderse o traspapelarse?.</p>',NULL,1,1,1,'2017-03-06 04:11:51','2017-03-06 09:20:42'),(3,'Pregunta 3','<p>En un examen de matemática solo el 75% de una clase respondió todas las preguntas. De aquellos que lo hicieron (responder todas las preguntas), el 80% aprobó el examen, pero de los que no respondieron todo, solo pasó el 50%. Si un estudiante aprobó el examen, ¿cuál es la probabilidad de que haya respondido todas las preguntas?.</p>',NULL,1,1,1,'2017-03-06 04:30:50','2017-03-06 09:31:14'),(4,'Pregunta 4','<p>Con un grupo de 12 personas, cuántos comités se pueden formar de 3 miembros?</p>',NULL,1,1,1,'2017-03-06 04:33:42','2017-03-06 09:34:13'),(5,'Pregunta 5','<p>En un sondeo de opinión se preguntó a 200 personas: ¿<i>cuál es su principal fuente de noticias?</i>. El cuadro a continuación resume los resultados:<i> </i></p>  <table>  <tbody><tr>   <td>      <br></td>   <td>   <p>televisión</p>   </td>   <td>   <p>periódico</p>   </td>   <td>   <p>radio</p>   </td>   <td>   <p>Internet</p>   </td>  </tr>  <tr>   <td>   <p>Mujer</p>   </td>   <td>   <p>70</p>   </td>   <td>   <p>30</p>   </td>   <td>   <p>15</p>   </td>   <td>   <p>5</p>   </td>  </tr>  <tr>   <td>   <p>Hombre</p>   </td>   <td>   <p>40</p>   </td>   <td>   <p>20</p>   </td>   <td>   <p>16</p>   </td>   <td>   <p>4</p>   </td>  </tr> </tbody></table>            Si se seleccionan dos personas al azar de la población de donde se tomó la muestra; determinar las probabilidades de que, las dos personas seleccionadas:sean un hombre y una mujer?',NULL,1,1,1,'2017-03-06 04:35:17','2017-03-06 09:36:17'),(6,'Pregunta 6','<ul><li>Una característica de interés en el proceso de llenado de té es el peso que contienen. Si las bolsas van semivacias se presentan 2 problemas. Primero, los clientes no podrían prepararse el té tan cargado como lo desean. Segundo, la empresa podría infringir las leyes de veracidad de lo escrito en la etiqueta. En este producto, el peso impreso en la etiqueta señala que en promedio hay 5.5 gramos de té en cada bolsa. Si la cantidad media de té en una bolsa supera este peso, la empresa está regalando producto.</li></ul>  <p>Resulta complicado introducir la cantidad exacta de té en cada bolsa, puesto que la variación en las condiciones de temperatura y humedad dentro de la fábrica, las diferencias en la densidad del té y la rápida operación de llenado que realiza la máquina (aproximadamente 170 bolsas por minuto). La siguiente tabla muestra el peso, en gramos de una muestra compuesta por 50 bolsas de té elaboradas en una hora por una sola máquina.</p>  <table>  <tbody><tr>   <td>   <p>5.65</p>   </td>   <td>   <p>5.44</p>   </td>   <td>   <p>5.42</p>   </td>   <td>   <p>5.40</p>   </td>   <td>   <p>5.53</p>   </td>   <td>   <p>5.34</p>   </td>   <td>   <p>5.54</p>   </td>   <td>   <p>5.45</p>   </td>   <td>   <p>5.52</p>   </td>   <td>   <p>5.41</p>   </td>  </tr>  <tr>   <td>   <p>5.57</p>   </td>   <td>   <p>5.40</p>   </td>   <td>   <p>5.53</p>   </td>   <td>   <p>5.54</p>   </td>   <td>   <p>5.55</p>   </td>   <td>   <p>5.62</p>   </td>   <td>   <p>5.56</p>   </td>   <td>   <p>5.46</p>   </td>   <td>   <p>5.44</p>   </td>   <td>   <p>5.51</p>   </td>  </tr>  <tr>   <td>   <p>5.47</p>   </td>   <td>   <p>5.40</p>   </td>   <td>   <p>5.47</p>   </td>   <td>   <p>5.61</p>   </td>   <td>   <p>5.53</p>   </td>   <td>   <p>5.32</p>   </td>   <td>   <p>5.67</p>   </td>   <td>   <p>5.29</p>   </td>   <td>   <p>5.49</p>   </td>   <td>   <p>5.55</p>   </td>  </tr>  <tr>   <td>   <p>5.77</p>   </td>   <td>   <p>5.57</p>   </td>   <td>   <p>5.42</p>   </td>   <td>   <p>5.58</p>   </td>   <td>   <p>5.58</p>   </td>   <td>   <p>5.50</p>   </td>   <td>   <p>5.32</p>   </td>   <td>   <p>5.50</p>   </td>   <td>   <p>5.53</p>   </td>   <td>   <p>5.58</p>   </td>  </tr>  <tr>   <td>   <p>5.61</p>   </td>   <td>   <p>5.45</p>   </td>   <td>   <p>5.44</p>   </td>   <td>   <p>5.25</p>   </td>   <td>   <p>5.56</p>   </td>   <td>   <p>5.63</p>   </td>   <td>   <p>5.50</p>   </td>   <td>   <p>5.57</p>   </td>   <td>   <p>5.67</p>   </td>   <td>   <p>5.36</p>   </td>  </tr> </tbody></table>    <p>Determine el tipo de variable</p>',NULL,1,1,1,'2017-03-06 04:39:15','2017-03-06 09:40:54'),(7,'Pregunta 7','<ul><li>Nos dan n=10 mediciones: 3, 4, 5, 6, 10, 5, 6, 9, 2, 8. La media, mediana y moda son respectivamente:</li></ul>',NULL,1,1,1,'2017-03-06 04:42:47','2017-03-06 09:42:57'),(8,'Pregunta 8','<p>Calcula la probabilidad de que al lanzar dos dados la suma de estos sea 6</p>',NULL,1,1,1,'2017-03-06 04:45:09','2017-03-06 09:45:18'),(9,'Pregunta 9','<ul><li>De un mazo de 52 cartas de póker, la probabilidad de sacar una reina está dada por:</li></ul>',NULL,1,1,1,'2017-03-06 04:47:38','2017-03-06 09:47:44'),(10,'Pregunta 10','<p \"=\"\">En Colombia, el baloto electrónico es un juego de azar, que consiste sacar 6 balotas en cualquier orden, de un grupo de 45 balotas. Cual es la probabilidad de ganarse el premio máximo? <br></p>',NULL,1,1,1,'2017-03-06 04:49:40','2017-03-06 09:51:29'),(11,'Pregunta 11','<p>¿Cual de las opciones siguientes son validas?<br></p>',NULL,2,1,1,'2017-03-07 11:16:05','2017-03-07 16:16:37'),(12,'Pregunta 12','<p \"=\"\">Si todos los valores en una muestra o en una poblacion son iguales, las varianzas y las desviaciones estandar serán iguales a cero?</p>',NULL,3,1,1,'2017-03-07 02:46:43','2017-03-08 15:08:08'),(13,'Pregunta 13','<p \"=\"\">Si 2+2 = 4, cual es la aceleracion de la gravedad?<br></p>',NULL,1,1,1,'2017-03-08 10:09:07','2017-03-08 15:09:46'),(14,'Pregunta 14','<p \"=\"\">Cual de los siguientes enunciados son verdaderos.<br></p>',NULL,1,1,1,'2017-03-08 10:11:48','2017-03-08 15:12:08'),(15,'Pregunta 15',NULL,NULL,2,1,0,'2017-03-08 10:13:14','2017-03-23 15:31:22'),(16,'Pregunta 16','<p>Hay algo mas rapido que la velocidad de la luz?<br></p>',NULL,3,1,1,'2017-03-08 10:14:01','2017-03-08 15:14:18'),(17,'Pregunta de completar',NULL,NULL,4,1,1,'2017-03-08 11:25:58','2017-03-08 16:25:58'),(19,'Pregunta de completar','El campeon de la champions es @pregunta',17,4,1,1,'2017-03-08 04:21:28','2017-03-08 09:21:28'),(20,'Pregunta de completar','Y del mundial es @pregunta',17,4,1,1,'2017-03-10 03:25:53','2017-03-10 08:25:53'),(21,'Pregunta 1','<p>El primer campeón mundial fue?<br></p>',NULL,1,4,1,'2017-03-15 05:02:31','2017-03-15 10:03:30'),(22,'Pregunta 2','<p>El equipo con mas títulos mundiales es ?<br></p>',NULL,1,4,1,'2017-03-15 05:05:18','2017-03-15 10:05:31'),(23,'Pregunta 3','<p \"=\"\">Cual de estos equipos nunca ha clasificado a una copa mundial?</p>',NULL,1,4,1,'2017-03-15 05:06:20','2017-03-15 10:06:44'),(24,'Pregunta 4','<p \"=\"\">Cual anfitrión ha quedado eliminado en la fase de grupos?<br></p>',NULL,1,4,1,'2017-03-15 05:11:38','2017-03-15 10:12:04'),(25,'Quien fue el goleador del mundial 2014','<p>Quien fue el goleador del mundial 2014<br></p>',NULL,1,4,1,'2017-03-15 05:13:12','2017-03-15 10:13:23'),(26,'Pregunta 6','<p \"=\"\">En el mundial de sudafrica sucedia un hecho histórico que fue:<br></p>',NULL,1,4,1,'2017-03-15 05:14:49','2017-03-15 10:15:19'),(27,'Pregunta 7','<p \"=\"\">Antes de brasil 2014, cual mundial fue donde llegó mas lejos?<br></p>',NULL,1,4,1,'2017-03-15 05:17:55','2017-03-15 10:19:02'),(28,'Pregunta 8','<p>El partido de Honduras Ecuador en el mundial 2014 marco un hecho<br></p>',NULL,1,4,1,'2017-03-15 05:19:58','2017-03-15 10:20:40'),(29,'Pregunta 9','<p \"=\"\">Cuales equipos han ganado por lo menos cuatro títulos<br></p>',NULL,2,4,1,'2017-03-15 05:23:31','2017-03-15 10:24:21'),(30,'Pregunta 10','<p \"=\"\">Cuales jugadores marcaron 5 goles en el mundial celebrado en sudafrica 2010<br></p>',NULL,2,4,1,'2017-03-15 05:26:48','2017-03-15 10:27:27'),(31,'Pregunta 1','<p \"=\"\">Cual es el resultado del siguiente operación 4*2+8<br></p>',NULL,1,5,1,'2017-04-06 10:23:00','2017-04-06 15:23:25'),(32,'Pregunta 2','<p \"=\"\">Antes de C++ habia otro lenguaje?</p>',NULL,3,5,1,'2017-04-06 10:24:31','2017-04-06 15:24:43'),(33,'Pregunta 3','<p \"=\"\">Cual no es un lenguaje de programación?<br></p>',NULL,2,5,1,'2017-04-06 10:25:16','2017-04-06 15:25:43'),(34,'Pregunta 4','<p>Cualquier cosa<br></p>',NULL,1,5,1,'2017-04-06 10:27:19','2017-04-06 15:27:38'),(36,'Pregunta 5','<p>CUal de estos no es valido<br></p>',NULL,1,5,1,'2017-04-06 10:29:15','2017-04-06 15:29:24'),(37,'Pregunta 6',NULL,NULL,4,5,1,'2017-04-06 10:59:08','2017-04-06 15:59:08'),(38,'subpregunta','Antes de c++ estaba el lenguaje @pregunta',37,4,5,1,'2017-04-06 12:04:35','2017-04-06 17:04:35'),(39,'Pregunta 6','Y este lenguaje evolucionó del lenguaje @pregunta',37,4,5,1,'2017-04-06 12:06:05','2017-04-06 17:06:05'),(40,'Pregunta 9',NULL,NULL,1,1,1,'2017-04-28 08:57:37','2017-04-28 13:57:37'),(41,'pregunta 1','<p>Como hacer clientes felices<br></p>',NULL,1,6,1,'2017-05-12 09:21:03','2017-05-12 14:21:14'),(42,'Pregunta 2','<p \"=\"\">Un resultado para las normas internas es</p>',NULL,1,6,1,'2017-05-12 09:27:46','2017-05-12 14:28:06'),(43,'Pregunta 3','<p \"=\"\">En copservir la mejor opcion de atender clientes es?</p>',NULL,1,6,1,'2017-05-12 09:29:42','2017-05-12 14:30:23'),(44,'Pregunta 1','<p \"=\"\">Quien es J.J?<br></p>',NULL,1,7,1,'2017-06-07 03:32:40','2017-06-07 08:32:54'),(45,'Que es EISO',NULL,NULL,4,7,1,'2017-06-07 03:34:07','2017-06-07 08:34:07'),(46,'Que es EISO','Estrategia e innovacion en soluciones @pregunta',45,4,7,1,'2017-06-07 03:34:30','2017-06-07 08:34:30'),(47,'safasfafd','<p>asfasfasdfasdf</p>',NULL,1,8,1,'2017-06-14 10:58:08','2017-06-14 15:58:22'),(48,'Pregunta 1','<p>¿Que hora es?</p><p><br></p>',NULL,1,9,1,'2017-06-14 11:05:01','2017-06-14 16:11:09'),(49,'Pregunta 2','<p \"=\"\">¿Son las 11?<br></p>',NULL,3,9,1,'2017-06-14 11:11:59','2017-06-14 16:12:12'),(50,'Pregunta 3',NULL,NULL,4,9,1,'2017-06-14 11:18:53','2017-06-14 16:18:53'),(51,'Pregunta 3','Hoy es @pregunta',50,4,9,1,'2017-06-14 11:19:52','2017-06-14 16:19:52'),(52,'Pregunta 3','A las @pregunta se realizó videoconferencia',50,4,9,1,'2017-06-14 11:20:14','2017-06-14 16:20:14'),(53,'Pregunta 1','<p>Que es un mensajero?<br></p>',NULL,1,10,1,'2017-07-06 12:07:19','2017-07-06 17:07:30'),(54,'Pregunta 2','<p \"=\"\">Un mensajero requiere de :<br></p>',NULL,1,10,1,'2017-07-06 12:08:35','2017-07-06 17:08:49'),(55,'pregunta 1','<p \"=\"\">Un mensajero dispone de lo siguiente<br></p>',NULL,1,11,1,'2017-07-06 12:10:43','2017-07-06 17:11:13'),(56,'Pregunta 2','<p \"=\"\">El mensajero debe disponer de licencia de conducción<br></p>',NULL,3,11,1,'2017-07-06 12:13:39','2017-07-06 17:14:03'),(57,'Pregunta 1','<p>Copservir es una empresa<br></p>',NULL,1,12,1,'2017-07-06 12:18:23','2017-07-06 17:18:32'),(58,'Pregunta 2','<p>Llevamos mas de 50 años en copservir<br></p>',NULL,3,12,1,'2017-07-06 12:21:33','2017-07-06 17:21:48'),(59,'?Que es php','<p>Que es php?</p>',NULL,1,14,1,'2017-07-07 12:20:02','2017-07-07 17:20:45'),(60,'pregunta suele','<p \"=\"\">PHP está enfocado principalmente a la programación de scripts del lado del cliente</p>',NULL,3,15,1,'2017-07-07 02:49:31','2017-07-07 07:49:43'),(61,'Pregunta necesita','<p \"=\"\">Cual es la extensión de los archivos para usar php</p>',NULL,1,16,1,'2017-07-07 02:52:27','2017-07-07 07:52:46'),(62,'script','<p \"=\"\">En este script cual será el resultado<code></code> visible en el navegador<br><code></code></p><div><div \"=\"\"><code> &lt;?php echo \'&lt;p&gt;Hola Mundo&lt;/p&gt;\'; ?&gt;</code></div></div>',NULL,1,17,1,'2017-07-07 02:55:52','2017-07-07 07:57:34'),(63,'Algo util',NULL,NULL,4,18,1,'2017-07-07 03:01:16','2017-07-07 08:01:16'),(64,'Algo util','En PHP, las variables siempre comienzan con un signo de @pregunta',63,4,18,1,'2017-07-07 03:01:54','2017-07-07 08:01:54'),(65,'input','<p>Son tipos de entradas?<br></p>',NULL,2,19,1,'2017-07-07 03:04:47','2017-07-07 08:05:03'),(66,'Codigo antiguo','<ul><li><span class=\"simpara\">Los antiguos arrays <var><var>$HTTP_*_VARS</var></var> ya no están disponibles a partir de PHP 5.4.0. Los siguientes <a href=\"http://php.net/manual/es/language.variables.superglobals.php\" class=\"link\">arrays superglobales</a> fueron introducidos en PHP <a href=\"http://www.php.net/releases/4_1_0.php\" class=\"link external\">» 4.1.0</a>. Son: </span></li></ul>',NULL,1,20,1,'2017-07-07 03:07:48','2017-07-07 08:08:28');
/*!40000 ALTER TABLE `m_FORCO_Pregunta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_Premio`
--

DROP TABLE IF EXISTS `m_FORCO_Premio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_Premio` (
  `idPremio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombrePremio` varchar(100) DEFAULT NULL,
  `descripcionPremio` longtext,
  `idCategoria` int(10) unsigned DEFAULT NULL,
  `puntosRedimir` int(11) unsigned DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT '1',
  `cantidad` int(11) unsigned DEFAULT NULL,
  `rutaImagen` varchar(100) DEFAULT NULL,
  `fechaInicioVigencia` datetime DEFAULT NULL,
  `fechaFinVigencia` datetime DEFAULT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tipoRedimir` tinyint(4) NOT NULL,
  `numeroPremios` int(10) DEFAULT NULL,
  `idCuestionario` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`idPremio`),
  KEY `fk_m_FORCO_Premio_m_FORCO_CategoriasPremios` (`idCategoria`),
  KEY `fk_m_FORCO_Premio_m_FORCO_Cuestionario` (`idCuestionario`),
  CONSTRAINT `fk_m_FORCO_Premio_m_FORCO_CategoriasPremios` FOREIGN KEY (`idCategoria`) REFERENCES `m_FORCO_CategoriasPremios` (`idCategoria`),
  CONSTRAINT `fk_m_FORCO_Premio_m_FORCO_Cuestionario` FOREIGN KEY (`idCuestionario`) REFERENCES `m_FORCO_Cuestionario` (`idCuestionario`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_Premio`
--

LOCK TABLES `m_FORCO_Premio` WRITE;
/*!40000 ALTER TABLE `m_FORCO_Premio` DISABLE KEYS */;
INSERT INTO `m_FORCO_Premio` VALUES (1,'Balon futbol','Balón de fútbol',16,50,1,8,'1493137316_.jpg','2017-04-01 00:00:00','2018-04-30 00:00:00','2017-04-25 11:21:22','2017-06-16 15:06:51',1,NULL,NULL),(2,'Balon baloncesto','Balon de baloncesto',17,50,1,9,'1493138279_.jpg','2017-04-01 00:00:00','2018-04-30 00:00:00','2017-04-25 11:37:59','2017-07-07 14:30:31',1,NULL,NULL),(3,'Licuadora','licuadora',16,30,1,50,'1493148275_.jpg','2017-04-01 00:00:00','2018-04-30 00:00:00','2017-04-25 02:24:35','2017-06-16 14:04:01',1,NULL,NULL),(4,'Televisor','Televisor',16,NULL,1,29,'1494450605_.jpg','2017-05-01 00:00:00','2017-06-30 00:00:00','2017-05-10 04:10:05','2017-06-16 14:04:33',0,NULL,9),(5,'prueba','asdfasdf',16,1,1,1,'1495058952_.png','2017-05-17 00:00:00','2017-05-17 00:00:00','2017-05-17 05:08:34','2017-06-16 14:04:01',1,NULL,NULL);
/*!40000 ALTER TABLE `m_FORCO_Premio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `m_FORCO_TipoPregunta`
--

DROP TABLE IF EXISTS `m_FORCO_TipoPregunta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `m_FORCO_TipoPregunta` (
  `idTipoPregunta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoPregunta` varchar(45) NOT NULL,
  `estado` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`idTipoPregunta`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `m_FORCO_TipoPregunta`
--

LOCK TABLES `m_FORCO_TipoPregunta` WRITE;
/*!40000 ALTER TABLE `m_FORCO_TipoPregunta` DISABLE KEYS */;
INSERT INTO `m_FORCO_TipoPregunta` VALUES (1,'Seleccion Múltiple Unica respuesta',1),(2,'Seleccion Multiple, múltiple respuesta',1),(3,'Verdadero/Falso',1),(4,'Completar',1);
/*!40000 ALTER TABLE `m_FORCO_TipoPregunta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_ContenidoCalificacion`
--

DROP TABLE IF EXISTS `t_FORCO_ContenidoCalificacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_ContenidoCalificacion` (
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `idContenido` int(10) unsigned NOT NULL,
  `titulo` varchar(45) NOT NULL,
  `comentario` varchar(100) NOT NULL,
  `calificacion` int(1) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`numeroDocumento`,`idContenido`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_ContenidoCalificacion`
--

LOCK TABLES `t_FORCO_ContenidoCalificacion` WRITE;
/*!40000 ALTER TABLE `t_FORCO_ContenidoCalificacion` DISABLE KEYS */;
INSERT INTO `t_FORCO_ContenidoCalificacion` VALUES (1113618983,2,'Exelente','asdf',4,'2017-03-27 19:33:13'),(1113618983,5,'Sasas','Comentario fasdfasdf',4,'2017-06-15 20:04:22'),(1113618983,6,'dfgsdfg','sdfgsdfg',5,'2017-04-06 17:24:40'),(1113618983,7,'asdf','asdf',5,'2017-06-15 20:07:56'),(1113618983,8,'Prueba','Promedio',3,'2017-06-15 20:19:04'),(1113618983,18,'Comentario','Buen contenido',4,'2017-06-16 14:43:33'),(1113618983,20,'Buen Cntenido','Exelente',5,'2017-06-14 14:49:46');
/*!40000 ALTER TABLE `t_FORCO_ContenidoCalificacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_ContenidoLeidoUsuario`
--

DROP TABLE IF EXISTS `t_FORCO_ContenidoLeidoUsuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_ContenidoLeidoUsuario` (
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `idContenido` int(10) unsigned NOT NULL DEFAULT '0',
  `fechaCreacion` datetime DEFAULT NULL,
  `idCurso` int(10) unsigned NOT NULL,
  `tiempoLectura` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`numeroDocumento`,`idContenido`),
  KEY `fk_t_FORCO_ContenidoLeidoUsuario_m_FORCO_Contenido` (`idContenido`),
  KEY `fk_t_FORCO_ContenidoLeidoUsuario_m_FORCO_Curso` (`idCurso`),
  CONSTRAINT `fk_t_FORCO_ContenidoLeidoUsuario_m_FORCO_Contenido` FOREIGN KEY (`idContenido`) REFERENCES `m_FORCO_Contenido` (`idContenido`),
  CONSTRAINT `fk_t_FORCO_ContenidoLeidoUsuario_m_FORCO_Curso` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`),
  CONSTRAINT `fk_t_FORCO_ContenidoLeidoUsuario_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_ContenidoLeidoUsuario`
--

LOCK TABLES `t_FORCO_ContenidoLeidoUsuario` WRITE;
/*!40000 ALTER TABLE `t_FORCO_ContenidoLeidoUsuario` DISABLE KEYS */;
INSERT INTO `t_FORCO_ContenidoLeidoUsuario` VALUES (1113618983,2,'2017-04-06 17:43:29',4,NULL),(1113618983,5,'2017-04-06 16:33:55',4,NULL),(1113618983,6,'2017-06-14 08:20:31',8,0),(1113618983,7,'2017-06-15 15:07:42',9,0),(1113618983,8,'2017-06-15 15:16:37',9,0),(1113618983,10,'2017-06-14 08:19:46',11,0),(1113618983,18,'2017-05-31 11:10:50',4,0),(1113618983,19,'2017-07-06 16:23:06',12,0),(1113618983,20,'2017-07-06 15:49:23',12,NULL),(1113618983,21,'2017-07-06 15:49:08',12,0),(1113618983,23,'2017-07-07 16:04:24',14,NULL),(1113618983,24,'2017-07-07 16:12:02',14,NULL);
/*!40000 ALTER TABLE `t_FORCO_ContenidoLeidoUsuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_CuestionarioUsuario`
--

DROP TABLE IF EXISTS `t_FORCO_CuestionarioUsuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_CuestionarioUsuario` (
  `idCuestionarioUsuario` int(11) NOT NULL AUTO_INCREMENT,
  `idCuestionario` int(10) unsigned NOT NULL,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `numeroPreguntasTotal` double DEFAULT NULL,
  `numeroPreguntasRespondidas` double DEFAULT NULL,
  `porcentajeObtenido` double DEFAULT NULL,
  `estadoCuestionario` tinyint(1) unsigned NOT NULL,
  `fechaCreacion` datetime NOT NULL,
  `fechaActualizacion` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`idCuestionarioUsuario`),
  KEY `fk_t_FORCO_CuestionarioUsuario_m_FORCO_Cuestionario1_idx` (`idCuestionario`),
  KEY `fk_t_FORCO_CuestionarioUsuario_m_Usuario1_idx` (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_CuestionarioUsuario_m_FORCO_Cuestionario1` FOREIGN KEY (`idCuestionario`) REFERENCES `m_FORCO_Cuestionario` (`idCuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_FORCO_CuestionarioUsuario_m_Usuario1` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_CuestionarioUsuario`
--

LOCK TABLES `t_FORCO_CuestionarioUsuario` WRITE;
/*!40000 ALTER TABLE `t_FORCO_CuestionarioUsuario` DISABLE KEYS */;
INSERT INTO `t_FORCO_CuestionarioUsuario` VALUES (21,5,1113618983,6,5,83.333333333333,2,'2017-04-05 02:44:39','2017-04-05 09:01:08'),(22,5,1113618983,NULL,NULL,NULL,1,'2017-04-05 04:18:23',NULL),(26,5,1113618983,5,1.3333333333333,26.666666666667,2,'2017-04-06 10:32:12','2017-04-06 15:32:49'),(27,5,1113618983,5,5,100,2,'2017-04-06 10:33:51','2017-04-06 15:34:19'),(31,5,1113618983,5,5,100,2,'2017-04-06 12:17:47','2017-04-06 08:08:04'),(32,5,1113618983,NULL,NULL,NULL,1,'2017-04-06 03:08:12',NULL),(39,6,1113618983,3,2,66.666666666667,2,'2017-06-07 03:51:26','2017-06-07 08:52:26'),(40,1,1113618983,NULL,NULL,NULL,1,'2017-06-14 03:49:40',NULL),(41,1,1113618983,3,1,33.333333333333,2,'2017-06-14 03:51:30','2017-06-14 08:52:35'),(42,1,1113618983,4,1,25,2,'2017-06-14 03:54:04','2017-06-14 08:55:10'),(43,1,1113618983,NULL,NULL,NULL,1,'2017-06-14 04:02:53',NULL),(44,1,1113618983,NULL,NULL,NULL,1,'2017-06-14 04:03:22',NULL),(45,1,1113618983,4,2,50,2,'2017-06-14 04:05:34','2017-06-14 09:06:39'),(46,1,1113618983,1,0,0,2,'2017-06-14 04:06:59','2017-06-14 09:07:04'),(47,1,1113618983,0,0,0,2,'2017-06-14 04:07:15','2017-06-14 09:12:13'),(48,1,1113618983,5,2,40,2,'2017-06-14 04:12:34','2017-06-14 09:13:40'),(49,9,1113618983,NULL,NULL,NULL,1,'2017-06-16 09:58:44',NULL),(50,9,1113618983,3,1,33.333333333333,2,'2017-06-16 10:02:40','2017-06-16 15:02:56'),(51,9,1113618983,3,2,66.666666666667,2,'2017-06-16 10:04:33','2017-06-16 15:04:50'),(52,1,1113618983,3,1,33.333333333333,2,'2017-06-16 04:20:39','2017-06-16 09:21:44'),(53,1,1113618983,6,1,16.666666666667,2,'2017-06-16 04:22:04','2017-06-16 09:22:54'),(54,7,1113618983,2,1,50,2,'2017-06-16 04:24:14','2017-06-16 09:24:34'),(56,13,1113618983,4,3,75,2,'2017-07-06 12:23:53','2017-07-06 07:45:21'),(57,12,1113618983,2,0,0,2,'2017-07-06 12:26:36','2017-07-06 17:26:54'),(58,10,1113618983,2,2,100,2,'2017-07-06 03:44:27','2017-07-06 08:48:33'),(59,11,1113618983,2,2,100,2,'2017-07-06 03:49:03','2017-07-06 08:49:23'),(60,14,1113618983,1,1,100,2,'2017-07-07 04:04:16','2017-07-07 09:04:23'),(61,15,1113618983,1,1,100,2,'2017-07-07 04:11:51','2017-07-07 09:12:02'),(62,21,1113618983,5,5,100,2,'2017-07-07 04:13:17','2017-07-07 09:21:38');
/*!40000 ALTER TABLE `t_FORCO_CuestionarioUsuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_CursosUsuario`
--

DROP TABLE IF EXISTS `t_FORCO_CursosUsuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_CursosUsuario` (
  `idCurso` int(10) unsigned NOT NULL,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaInicioLectura` datetime DEFAULT NULL,
  PRIMARY KEY (`idCurso`,`numeroDocumento`),
  KEY `fk_t_FORCO_CursosUsuario_m_Usuario` (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_CursosUsuario_m_FORCO_Curso` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`),
  CONSTRAINT `fk_t_FORCO_CursosUsuario_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_CursosUsuario`
--

LOCK TABLES `t_FORCO_CursosUsuario` WRITE;
/*!40000 ALTER TABLE `t_FORCO_CursosUsuario` DISABLE KEYS */;
INSERT INTO `t_FORCO_CursosUsuario` VALUES (12,1113618983,'2017-07-06 16:23:06','2017-07-06 15:49:08'),(14,1113618983,'2017-07-07 04:21:38','2017-07-07 04:21:38');
/*!40000 ALTER TABLE `t_FORCO_CursosUsuario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_ModuloGruposInteres`
--

DROP TABLE IF EXISTS `t_FORCO_ModuloGruposInteres`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_ModuloGruposInteres` (
  `idModulo` int(10) unsigned NOT NULL,
  `idGrupoInteres` int(10) unsigned NOT NULL,
  PRIMARY KEY (`idModulo`,`idGrupoInteres`),
  KEY `fk_t_FORCO_ModuloGruposInteres_m_GrupoInteres_idx` (`idGrupoInteres`),
  CONSTRAINT `fk_t_FORCO_ModuloGruposInteres_m_FORCO_Modulo` FOREIGN KEY (`idModulo`) REFERENCES `m_FORCO_Modulo` (`idModulo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_FORCO_ModuloGruposInteres_m_GrupoInteres` FOREIGN KEY (`idGrupoInteres`) REFERENCES `m_GrupoInteres` (`idGrupoInteres`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_ModuloGruposInteres`
--

LOCK TABLES `t_FORCO_ModuloGruposInteres` WRITE;
/*!40000 ALTER TABLE `t_FORCO_ModuloGruposInteres` DISABLE KEYS */;
INSERT INTO `t_FORCO_ModuloGruposInteres` VALUES (9,1),(12,1),(9,2),(11,2),(12,2),(9,3),(11,3),(12,3),(9,4),(11,4),(12,4),(9,999999),(11,999999),(12,999999),(9,1000015),(12,1000015);
/*!40000 ALTER TABLE `t_FORCO_ModuloGruposInteres` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_Puntos`
--

DROP TABLE IF EXISTS `t_FORCO_Puntos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_Puntos` (
  `idPunto` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `valorPuntos` int(11) unsigned NOT NULL,
  `descripcionPunto` varchar(100) NOT NULL,
  `idCuestionario` int(10) unsigned DEFAULT NULL,
  `tipoParametro` int(10) DEFAULT NULL,
  `condicion` int(2) unsigned DEFAULT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `idPuntoSincronizado` int(10) unsigned DEFAULT NULL,
  `idCurso` int(10) unsigned DEFAULT NULL,
  `idParametroPunto` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`idPunto`),
  KEY `fk_t_FORCO_Puntos_m_FORCO_Cuestionario` (`idCuestionario`),
  KEY `fk_t_FORCO_Puntos_m_Usuario` (`numeroDocumento`),
  KEY `idCurso` (`idCurso`),
  CONSTRAINT `fk_t_FORCO_Puntos_m_FORCO_Cuestionario` FOREIGN KEY (`idCuestionario`) REFERENCES `m_FORCO_Cuestionario` (`idCuestionario`),
  CONSTRAINT `fk_t_FORCO_Puntos_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`),
  CONSTRAINT `t_FORCO_Puntos_ibfk_1` FOREIGN KEY (`idCurso`) REFERENCES `m_FORCO_Curso` (`idCurso`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_Puntos`
--

LOCK TABLES `t_FORCO_Puntos` WRITE;
/*!40000 ALTER TABLE `t_FORCO_Puntos` DISABLE KEYS */;
INSERT INTO `t_FORCO_Puntos` VALUES (1,1113618983,0,'CUESTIONARIO REALIZADO',13,4,NULL,'2017-07-06 14:45:21',NULL,12,NULL),(2,1113618983,0,'CUESTIONARIO REALIZADO',10,3,NULL,'2017-07-06 15:48:33',NULL,12,NULL),(3,94504074,0,'CUESTIONARIO REALIZADO',11,3,NULL,'2017-07-06 15:49:23',NULL,12,NULL),(4,1113618983,0,'CUESTIONARIO REALIZADO',14,3,NULL,'2017-07-07 16:04:24',NULL,14,NULL),(5,1113618983,0,'CUESTIONARIO REALIZADO',15,3,NULL,'2017-07-07 16:12:02',NULL,14,NULL),(6,1113618983,100,'CUESTIONARIO REALIZADO',21,4,NULL,'2017-07-07 16:21:38',NULL,14,NULL);
/*!40000 ALTER TABLE `t_FORCO_Puntos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_PuntosTotales`
--

DROP TABLE IF EXISTS `t_FORCO_PuntosTotales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_PuntosTotales` (
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `puntos` int(10) unsigned NOT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_PuntosTotales_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_PuntosTotales`
--

LOCK TABLES `t_FORCO_PuntosTotales` WRITE;
/*!40000 ALTER TABLE `t_FORCO_PuntosTotales` DISABLE KEYS */;
INSERT INTO `t_FORCO_PuntosTotales` VALUES (8742278,200,'2017-04-26 23:49:21'),(16686636,200,'2017-04-26 23:40:56'),(72206440,200,'2017-04-26 23:49:21'),(79692485,200,'2017-04-26 23:40:56'),(1113618983,290,'2017-06-16 21:24:38');
/*!40000 ALTER TABLE `t_FORCO_PuntosTotales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_Respuestas`
--

DROP TABLE IF EXISTS `t_FORCO_Respuestas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_Respuestas` (
  `idRespuesta` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `idPregunta` int(10) unsigned NOT NULL,
  `idOpcionRespuesta` int(10) unsigned DEFAULT NULL,
  `esCorrecta` int(10) unsigned DEFAULT NULL,
  `idCuestionario` int(10) unsigned DEFAULT NULL,
  `respuestaTextual` varchar(255) NOT NULL,
  `idCuestionarioUsuario` int(11) NOT NULL,
  PRIMARY KEY (`idRespuesta`),
  KEY `fk_t_FORCO_Respuestas_m_Usuario1_idx` (`numeroDocumento`),
  KEY `fk_t_FORCO_Respuestas_m_FORCO_Pregunta1_idx` (`idPregunta`),
  KEY `fk_t_FORCO_Respuestas_m_FORCO_OpcionRespuesta1_idx` (`idOpcionRespuesta`),
  KEY `fk_t_FORCO_Respuestas_m_FORCO_idCuestionario_idx` (`idCuestionario`),
  KEY `idCuestionarioUsuario` (`idCuestionarioUsuario`),
  CONSTRAINT `fk_t_FORCO_Respuestas_m_FORCO_Cuestionario` FOREIGN KEY (`idCuestionario`) REFERENCES `m_FORCO_Cuestionario` (`idCuestionario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_FORCO_Respuestas_m_FORCO_OpcionRespuesta1` FOREIGN KEY (`idOpcionRespuesta`) REFERENCES `m_FORCO_OpcionRespuesta` (`idOpcionRespuesta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_FORCO_Respuestas_m_FORCO_Pregunta1` FOREIGN KEY (`idPregunta`) REFERENCES `m_FORCO_Pregunta` (`idPregunta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_FORCO_Respuestas_m_Usuario1` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `t_FORCO_Respuestas_ibfk_1` FOREIGN KEY (`idCuestionarioUsuario`) REFERENCES `t_FORCO_CuestionarioUsuario` (`idCuestionarioUsuario`)
) ENGINE=InnoDB AUTO_INCREMENT=1128 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_Respuestas`
--

LOCK TABLES `t_FORCO_Respuestas` WRITE;
/*!40000 ALTER TABLE `t_FORCO_Respuestas` DISABLE KEYS */;
INSERT INTO `t_FORCO_Respuestas` VALUES (886,1113618983,14,57,1,1,'',21),(887,1113618983,1,3,1,1,'',21),(888,1113618983,13,54,1,1,'',21),(889,1113618983,3,14,0,1,'',21),(890,1113618983,12,51,1,1,'',21),(891,1113618983,7,27,1,1,'',21),(892,1113618983,14,57,1,1,'',21),(893,1113618983,1,3,1,1,'',21),(894,1113618983,13,54,1,1,'',21),(895,1113618983,3,14,0,1,'',21),(896,1113618983,12,51,1,1,'',21),(897,1113618983,7,27,1,1,'',21),(898,1113618983,14,57,1,1,'',21),(899,1113618983,1,3,1,1,'',21),(900,1113618983,13,54,1,1,'',21),(901,1113618983,3,14,0,1,'',21),(902,1113618983,12,51,1,1,'',21),(903,1113618983,7,27,1,1,'',21),(910,1113618983,14,57,1,1,'',21),(911,1113618983,1,3,1,1,'',21),(912,1113618983,13,54,1,1,'',21),(913,1113618983,3,14,0,1,'',21),(914,1113618983,12,51,1,1,'',21),(915,1113618983,7,27,1,1,'',21),(940,1113618983,14,57,1,1,'',21),(941,1113618983,1,3,1,1,'',21),(942,1113618983,13,54,1,1,'',21),(943,1113618983,3,14,0,1,'',21),(944,1113618983,12,51,1,1,'',21),(945,1113618983,7,27,1,1,'',21),(946,1113618983,31,123,1,5,'',26),(947,1113618983,32,128,0,5,'',26),(948,1113618983,36,139,0,5,'',26),(949,1113618983,34,135,0,5,'',26),(950,1113618983,33,132,0,5,'',26),(951,1113618983,33,129,1,5,'',26),(952,1113618983,34,134,1,5,'',27),(953,1113618983,31,123,1,5,'',27),(954,1113618983,32,127,1,5,'',27),(955,1113618983,33,131,1,5,'',27),(956,1113618983,33,129,1,5,'',27),(957,1113618983,36,137,1,5,'',27),(958,1113618983,34,134,1,5,'',31),(959,1113618983,31,123,1,5,'',31),(960,1113618983,33,131,1,5,'',31),(961,1113618983,33,129,1,5,'',31),(962,1113618983,38,141,1,5,'C',31),(963,1113618983,39,142,1,5,'B',31),(964,1113618983,32,127,1,5,'',31),(965,1113618983,34,134,1,5,'',31),(966,1113618983,31,123,1,5,'',31),(967,1113618983,33,131,1,5,'',31),(968,1113618983,33,129,1,5,'',31),(969,1113618983,38,141,1,5,'C',31),(970,1113618983,39,142,1,5,'B',31),(971,1113618983,32,127,1,5,'',31),(972,1113618983,34,134,1,5,'',31),(973,1113618983,31,123,1,5,'',31),(974,1113618983,33,131,1,5,'',31),(975,1113618983,33,129,1,5,'',31),(976,1113618983,38,141,1,5,'C',31),(977,1113618983,39,142,1,5,'B',31),(978,1113618983,32,127,1,5,'',31),(979,1113618983,34,134,1,5,'',31),(980,1113618983,31,123,1,5,'',31),(981,1113618983,33,131,1,5,'',31),(982,1113618983,33,129,1,5,'',31),(983,1113618983,38,141,1,5,'C',31),(984,1113618983,39,142,1,5,'B',31),(985,1113618983,32,127,1,5,'',31),(986,1113618983,34,134,1,5,'',31),(987,1113618983,31,123,1,5,'',31),(988,1113618983,33,131,1,5,'',31),(989,1113618983,33,129,1,5,'',31),(990,1113618983,38,141,1,5,'C',31),(991,1113618983,39,142,1,5,'B',31),(992,1113618983,32,127,1,5,'',31),(993,1113618983,6,26,1,1,'',34),(994,1113618983,16,61,1,1,'',34),(995,1113618983,7,29,0,1,'',34),(996,1113618983,10,43,0,1,'',34),(997,1113618983,9,37,1,1,'',34),(998,1113618983,1,4,0,1,'',34),(999,1113618983,5,22,0,1,'',35),(1000,1113618983,1,3,1,1,'',35),(1001,1113618983,16,61,1,1,'',35),(1002,1113618983,14,57,1,1,'',35),(1003,1113618983,19,64,1,1,'real madrid',35),(1004,1113618983,20,65,1,1,'alemania',35),(1005,1113618983,7,28,0,1,'',35),(1006,1113618983,10,43,0,1,'',36),(1007,1113618983,12,51,1,1,'',36),(1008,1113618983,5,19,1,1,'',36),(1009,1113618983,7,27,1,1,'',36),(1010,1113618983,1,3,1,1,'',36),(1011,1113618983,19,64,1,1,'real madrid',36),(1012,1113618983,20,65,1,1,'alemania',36),(1019,1113618983,1,3,1,1,'',37),(1020,1113618983,10,43,0,1,'',37),(1021,1113618983,13,54,1,1,'',37),(1022,1113618983,2,9,1,1,'',37),(1023,1113618983,9,37,1,1,'',37),(1024,1113618983,3,13,1,1,'',37),(1031,1113618983,42,146,1,6,'',39),(1032,1113618983,43,149,0,6,'',39),(1033,1113618983,41,143,1,6,'',39),(1034,1113618983,2,8,0,1,'',41),(1035,1113618983,13,53,0,1,'',41),(1036,1113618983,8,33,1,1,'',41),(1037,1113618983,13,56,0,1,'',42),(1038,1113618983,10,41,0,1,'',42),(1039,1113618983,3,13,1,1,'',42),(1040,1113618983,19,NULL,0,1,'',42),(1041,1113618983,20,NULL,0,1,'',42),(1042,1113618983,4,18,0,1,'',45),(1043,1113618983,13,54,1,1,'',45),(1044,1113618983,14,57,1,1,'',45),(1045,1113618983,6,23,0,1,'',45),(1046,1113618983,19,NULL,0,1,'',46),(1047,1113618983,20,NULL,0,1,'',46),(1063,1113618983,10,44,0,1,'',48),(1064,1113618983,12,52,0,1,'',48),(1065,1113618983,6,24,0,1,'',48),(1066,1113618983,16,61,1,1,'',48),(1067,1113618983,14,57,1,1,'',48),(1068,1113618983,51,164,1,9,'lunes',50),(1069,1113618983,52,167,1,9,'11',50),(1070,1113618983,49,163,0,9,'',50),(1071,1113618983,48,159,0,9,'',50),(1072,1113618983,48,161,1,9,'',51),(1073,1113618983,49,162,1,9,'',51),(1074,1113618983,51,NULL,0,9,'miercoles',51),(1075,1113618983,52,167,1,9,'11',51),(1076,1113618983,16,61,1,1,'',52),(1077,1113618983,8,35,0,1,'',52),(1078,1113618983,2,8,0,1,'',52),(1079,1113618983,16,61,1,1,'',53),(1080,1113618983,1,2,0,1,'',53),(1081,1113618983,5,22,0,1,'',53),(1082,1113618983,10,41,0,1,'',53),(1083,1113618983,19,NULL,0,1,'madrid',53),(1084,1113618983,20,65,1,1,'alemania',53),(1085,1113618983,9,39,0,1,'',53),(1086,1113618983,46,NULL,0,7,'eiso',54),(1087,1113618983,44,154,1,7,'',54),(1093,1113618983,58,183,0,12,'',57),(1094,1113618983,57,182,0,12,'',57),(1105,1113618983,57,181,1,13,'',56),(1106,1113618983,58,184,1,13,'',56),(1107,1113618983,51,NULL,0,13,'no se',56),(1108,1113618983,52,168,1,13,'once',56),(1109,1113618983,54,173,1,13,'',56),(1112,1113618983,53,171,1,10,'',58),(1113,1113618983,54,173,1,10,'',58),(1114,1113618983,55,175,1,11,'',59),(1115,1113618983,56,178,1,11,'',59),(1116,1113618983,59,185,1,14,'',60),(1117,1113618983,60,189,1,15,'',61),(1123,1113618983,60,189,1,21,'',62),(1124,1113618983,59,185,1,21,'',62),(1125,1113618983,64,203,1,21,'pesos',62),(1126,1113618983,62,197,1,21,'',62),(1127,1113618983,66,209,1,21,'',62);
/*!40000 ALTER TABLE `t_FORCO_Respuestas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_RestriccionesRedencion`
--

DROP TABLE IF EXISTS `t_FORCO_RestriccionesRedencion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_RestriccionesRedencion` (
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `fechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`numeroDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_RestriccionesRedencion`
--

LOCK TABLES `t_FORCO_RestriccionesRedencion` WRITE;
/*!40000 ALTER TABLE `t_FORCO_RestriccionesRedencion` DISABLE KEYS */;
INSERT INTO `t_FORCO_RestriccionesRedencion` VALUES (1113618981,'2017-06-14 22:21:01');
/*!40000 ALTER TABLE `t_FORCO_RestriccionesRedencion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_UsuariosPremios`
--

DROP TABLE IF EXISTS `t_FORCO_UsuariosPremios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_UsuariosPremios` (
  `idUsuarioPremio` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idPremio` int(10) unsigned NOT NULL,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `cantidad` int(10) unsigned NOT NULL,
  `puntosRedimir` int(10) unsigned NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `fechaCreacion` datetime DEFAULT NULL,
  `fechaActualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `fechaEntrega` date DEFAULT NULL,
  PRIMARY KEY (`idUsuarioPremio`),
  KEY `fk_t_FORCO_UsuariosPremios_m_FORCO_Premio` (`idPremio`),
  KEY `fk_t_FORCO_UsuariosPremios_m_Usuario` (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_UsuariosPremios_m_FORCO_Premio` FOREIGN KEY (`idPremio`) REFERENCES `m_FORCO_Premio` (`idPremio`),
  CONSTRAINT `fk_t_FORCO_UsuariosPremios_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_UsuariosPremios`
--

LOCK TABLES `t_FORCO_UsuariosPremios` WRITE;
/*!40000 ALTER TABLE `t_FORCO_UsuariosPremios` DISABLE KEYS */;
INSERT INTO `t_FORCO_UsuariosPremios` VALUES (3,1,1113618983,1,50,3,'2017-04-26 04:18:09','2017-06-07 21:42:00','2017-05-22'),(4,1,1113618983,1,50,3,'2017-04-26 04:18:34','2017-04-27 20:19:51',NULL),(5,1,1113618983,1,50,3,'2017-05-08 10:42:05','2017-05-12 21:36:02',NULL),(6,4,1113618983,1,0,3,'2017-05-11 08:44:22','2017-05-12 21:36:03',NULL),(7,1,1113618983,1,50,2,'2017-05-12 10:17:16','2017-05-16 14:52:28','2017-05-24'),(8,2,1113618983,1,50,2,'2017-05-12 10:17:22','2017-05-12 15:19:21',NULL),(9,1,1113618983,1,50,1,'2017-06-16 10:07:15','2017-06-16 15:06:51',NULL);
/*!40000 ALTER TABLE `t_FORCO_UsuariosPremios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `t_FORCO_UsuariosPremiosTrazabilidad`
--

DROP TABLE IF EXISTS `t_FORCO_UsuariosPremiosTrazabilidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `t_FORCO_UsuariosPremiosTrazabilidad` (
  `idTrazabilidad` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `idUsuarioPremio` int(10) unsigned NOT NULL,
  `idPremio` int(10) unsigned NOT NULL,
  `numeroDocumento` bigint(20) unsigned NOT NULL,
  `estado` tinyint(4) NOT NULL,
  `numeroDocumentoTraza` bigint(20) unsigned NOT NULL,
  `fechaRegistro` datetime DEFAULT NULL,
  `observacion` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`idTrazabilidad`),
  KEY `fk_t_FORCO_UsuariosPremiosTrazabilidad_t_FORCO_UsuariosPremios` (`idUsuarioPremio`),
  KEY `fk_t_FORCO_UsuariosPremiosTrazabilidad_m_FORCO_Premio` (`idPremio`),
  KEY `fk_t_FORCO_UsuariosPremiosTrazabilidad_m_Usuario` (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_UsuariosPremiosTrazabilidad_m_FORCO_Premio` FOREIGN KEY (`idPremio`) REFERENCES `m_FORCO_Premio` (`idPremio`),
  CONSTRAINT `fk_t_FORCO_UsuariosPremiosTrazabilidad_m_Usuario` FOREIGN KEY (`numeroDocumento`) REFERENCES `m_Usuario` (`numeroDocumento`),
  CONSTRAINT `fk_t_FORCO_UsuariosPremiosTrazabilidad_t_FORCO_UsuariosPremios` FOREIGN KEY (`idUsuarioPremio`) REFERENCES `t_FORCO_UsuariosPremios` (`idUsuarioPremio`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `t_FORCO_UsuariosPremiosTrazabilidad`
--

LOCK TABLES `t_FORCO_UsuariosPremiosTrazabilidad` WRITE;
/*!40000 ALTER TABLE `t_FORCO_UsuariosPremiosTrazabilidad` DISABLE KEYS */;
INSERT INTO `t_FORCO_UsuariosPremiosTrazabilidad` VALUES (2,3,1,1113618983,1,1113618983,'2017-04-26 04:18:09',NULL),(3,4,1,1113618983,1,1113618983,'2017-04-26 04:18:34',NULL),(4,3,1,1113618983,2,1113618983,'2017-04-27 03:19:11',NULL),(5,3,1,1113618983,2,1113618983,'2017-04-27 03:19:39',NULL),(6,4,1,1113618983,3,1113618983,'2017-04-27 03:20:26',NULL),(7,3,1,1113618983,2,1113618983,'2017-05-05 04:02:11',NULL),(8,5,1,1113618983,1,1113618983,'2017-05-08 10:42:05',NULL),(9,6,4,1113618983,1,1113618983,'2017-05-11 08:44:22',NULL),(10,7,1,1113618983,1,1113618983,'2017-05-12 10:17:16',NULL),(11,8,2,1113618983,1,1113618983,'2017-05-12 10:17:22',NULL),(12,7,1,1113618983,2,1113618983,'2017-05-12 10:19:51',NULL),(13,8,2,1113618983,2,1113618983,'2017-05-12 10:19:51',NULL),(14,5,1,1113618983,3,1113618983,'2017-05-12 04:36:33',NULL),(15,6,4,1113618983,3,1113618983,'2017-05-12 04:36:33',NULL),(16,8,2,1113618983,2,1113618983,'2017-05-16 08:52:39',NULL),(17,3,1,1113618983,2,1113618983,'2017-05-16 09:46:06',NULL),(18,7,1,1113618983,2,1113618983,'2017-05-16 09:46:06',NULL),(19,3,1,1113618983,2,1113618983,'2017-05-16 09:50:36',NULL),(20,7,1,1113618983,2,1113618983,'2017-05-16 09:50:36',NULL),(21,7,1,1113618983,2,1113618983,'2017-05-16 09:52:59','observacion'),(22,3,1,1113618983,3,1113618983,'2017-06-07 04:42:28',''),(23,9,1,1113618983,1,1113618983,'2017-06-16 10:07:15',NULL);
/*!40000 ALTER TABLE `t_FORCO_UsuariosPremiosTrazabilidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'intranet2'
--
/*!50003 DROP PROCEDURE IF EXISTS `proc_trademarketing_cargueVentas` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_trademarketing_cargueVentas`(in newIdComercial varchar(45), in newIdAgrupacion int(11), in newMes int(2))
BEGIN
	declare _antId int default null;
    declare _antPdv varchar(10) default null;
    declare _antUnidad int (11) default null;
    declare _antMes int(2) default null;
    declare _antValor bigint default null;
    declare _antUnidades bigint default null;
    declare _antFecha timestamp default null;
    
    declare _actId int default null;
    declare _actPdv varchar(10) default null;
    declare _actUnidad int (11) default null;
    declare _actMes int(2) default null;
    declare _actValor bigint default null;
    declare _actUnidades bigint default null;
    declare _actFecha timestamp default null;
    
    SET @fecha = current_timestamp();
    
    -- consultar registro en tabla anterior
    SELECT idInformacionVentasAnterior, idComercial, idAgrupacion, mes, valor, unidades, fechaRegistro
    INTO _antId, _antPdv, _antUnidad, _antMes, _antValor, _antUnidades, _antFecha
    FROM t_TRMA_InformacionVentasAnterior 
    WHERE idComercial=newIdComercial AND idAgrupacion=newIdAgrupacion AND mes=newMes 
    limit 1;
    
    if _antId is null or ( _antId is not null and year(@fecha)>year(_antFecha))
    then -- si no hay anterior o si hay pero no se han migrado datos --> migrar actual a anterior
        -- consultar registro actual
		SELECT idInformacionVentasActual, idComercial, idAgrupacion, mes, valor, unidades, fechaRegistro
        INTO _actId, _actPdv, _actUnidad, _actMes, _actValor, _actUnidades, _actFecha
		FROM t_TRMA_InformacionVentasActual 
		WHERE idComercial=newIdComercial AND idAgrupacion=newIdAgrupacion AND mes=newMes 
		limit 1;
        
        if _actId is not null
		then -- si actual existe poblar anterior
            if _antId is null
            then -- si no existe insertar
				insert into t_TRMA_InformacionVentasAnterior (idComercial, idAgrupacion, mes, valor, unidades) values (_actPdv,_actUnidad,_actMes,_actValor,_actUnidades); 
            else -- si existe actualizar
				update t_TRMA_InformacionVentasAnterior set valor=_actValor, unidades=_actUnidades where idInformacionVentasAnterior=_antId;
            end if;
        end if;
    end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-07 16:44:01
