<!-- <div class="p-t-30 p-l-40 p-b-20 xs-p-t-10 xs-p-l-10 xs-p-b-10"> -->
<div class="container">
  <div class="row">
    <h2 class="normal">
      Revisa tu Correo
    </h2>
    <p>
      Se te ha enviado un mensaje con las instrucciones para la recuperación de la contraseña, por favor revisa tu correo <?= $correo ?>.
    </p>
  </div>
</div>
<!-- </div> -->
