<?php
namespace app\modules\proveedores\modules\visitamedica\models;

class CorreoAdminForm extends \yii\base\Model
{
    public $contenido;

    public function rules()
    {
        return [
            // define validation rules here
        ];
    }
}