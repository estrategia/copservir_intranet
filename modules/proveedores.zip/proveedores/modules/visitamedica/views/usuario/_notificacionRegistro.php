<h1>Usuario Registrado</h1>
<p>Se ha registrado con exito tu usuario en el sistema.</p>
<h3>
  Tus credenciales son:
</h3>
<p>
  <strong>Usuario:</strong> <?php echo $infoUsuario['usuario']; ?> <br>
  <strong>Contraseña:</strong> <?php echo $infoUsuario['password']; ?>
</p>