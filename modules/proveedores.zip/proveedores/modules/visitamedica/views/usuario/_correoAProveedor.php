<h1> <?php echo $visitador['nombre'] ?> <?php echo $visitador['primerApellido']; ?> te ha enviado un mensaje: </h1>
<p> <?php echo $mensaje ?> </p>