<?php

namespace app\modules\proveedores\controllers;

use app\controllers\CController;
use Yii;
use yii\web\Controller;
use app\modules\intranet\models\Portal;
use app\modules\intranet\models\Contenido;

class SitioController extends CController
{
}

?>
