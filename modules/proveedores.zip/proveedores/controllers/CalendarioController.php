<?php

namespace app\modules\proveedores\controllers;

use app\controllers\ControllerCalendar;

class CalendarioController extends ControllerCalendar {

}
